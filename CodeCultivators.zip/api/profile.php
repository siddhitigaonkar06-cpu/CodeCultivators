<?php
// API: User Profile
require_once __DIR__ . '/../auth/check.php';

$db = getDB();
$user = $_SESSION['user'];
$action = $_GET['action'] ?? $_POST['action'] ?? 'get';

switch ($action) {

    case 'get':
        $stmt = $db->prepare("
            SELECT u.id, u.phone, u.email, u.role, u.full_name, u.display_name, u.avatar_url,
                   u.preferred_language, u.is_verified, u.created_at,
                   up.aadhaar_verified, up.kcc_verified, up.firm_name, up.firm_type,
                   up.total_land_acres, up.primary_crops, up.rating, up.total_transactions, up.bio
            FROM users u
            LEFT JOIN user_profiles up ON u.id = up.user_id
            WHERE u.id = ?
        ");
        $stmt->execute([$user['id']]);
        $profile = $stmt->fetch();

        // Address
        $addr = $db->prepare("SELECT * FROM user_addresses WHERE user_id = ? AND is_default = 1 LIMIT 1");
        $addr->execute([$user['id']]);
        $profile['address'] = $addr->fetch();

        // Bank
        $bank = $db->prepare("SELECT * FROM user_bank_details WHERE user_id = ? AND is_primary = 1 LIMIT 1");
        $bank->execute([$user['id']]);
        $profile['bank'] = $bank->fetch();

        // FPO membership
        $fpo = $db->prepare("
            SELECT fo.name, fm.member_role
            FROM fpo_members fm JOIN fpo_organizations fo ON fm.fpo_id = fo.id
            WHERE fm.user_id = ? AND fm.status = 'active' LIMIT 1
        ");
        $fpo->execute([$user['id']]);
        $profile['fpo_membership'] = $fpo->fetch();

        jsonResponse(['profile' => $profile]);
        break;

    case 'update':
        $full_name = sanitize($_POST['full_name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $language = sanitize($_POST['preferred_language'] ?? 'en');

        if (!empty($full_name)) {
            $db->prepare("UPDATE users SET full_name = ?, display_name = ?, email = ?, preferred_language = ? WHERE id = ?")
               ->execute([$full_name, $full_name, $email ?: null, $language, $user['id']]);
            $_SESSION['user']['full_name'] = $full_name;
            $_SESSION['user']['display_name'] = $full_name;
            $_SESSION['user']['preferred_language'] = $language;
        }

        // Update profile
        $firm_name = sanitize($_POST['firm_name'] ?? '');
        $land_acres = floatval($_POST['total_land_acres'] ?? 0) ?: null;
        $bio = sanitize($_POST['bio'] ?? '');
        $db->prepare("UPDATE user_profiles SET firm_name = ?, total_land_acres = ?, bio = ? WHERE user_id = ?")
           ->execute([$firm_name ?: null, $land_acres, $bio ?: null, $user['id']]);

        jsonResponse(['success' => true]);
        break;

    case 'update_bank':
        $bankName = sanitize($_POST['bank_name'] ?? '');
        $accountNumber = sanitize($_POST['account_number'] ?? '');
        $ifsc = sanitize($_POST['ifsc_code'] ?? '');
        $upi = sanitize($_POST['upi_id'] ?? '');

        // Upsert
        $existing = $db->prepare("SELECT id FROM user_bank_details WHERE user_id = ? AND is_primary = 1");
        $existing->execute([$user['id']]);
        if ($existing->fetch()) {
            $db->prepare("UPDATE user_bank_details SET bank_name = ?, account_number = ?, ifsc_code = ?, upi_id = ? WHERE user_id = ? AND is_primary = 1")
               ->execute([$bankName, $accountNumber, $ifsc, $upi ?: null, $user['id']]);
        } else {
            $db->prepare("INSERT INTO user_bank_details (user_id, account_holder_name, bank_name, account_number, ifsc_code, upi_id) VALUES (?, ?, ?, ?, ?, ?)")
               ->execute([$user['id'], $user['full_name'], $bankName, $accountNumber, $ifsc, $upi ?: null]);
        }

        jsonResponse(['success' => true]);
        break;

    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}
