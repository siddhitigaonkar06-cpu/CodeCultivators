<?php
// API: Grievances & Disputes
require_once __DIR__ . '/../auth/check.php';

$db = getDB();
$user = $_SESSION['user'];
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {

    case 'list':
        $stmt = $db->prepare("
            SELECT g.*, u.full_name AS against_user_name, o.order_code
            FROM grievances g
            LEFT JOIN users u ON g.against_user_id = u.id
            LEFT JOIN orders o ON g.order_id = o.id
            WHERE g.filed_by = ?
            ORDER BY g.created_at DESC
        ");
        $stmt->execute([$user['id']]);
        $grievances = $stmt->fetchAll();

        // Attach updates
        foreach ($grievances as &$g) {
            $upd = $db->prepare("SELECT gu.*, u.full_name AS updater_name FROM grievance_updates gu LEFT JOIN users u ON gu.update_by = u.id WHERE gu.grievance_id = ? ORDER BY gu.created_at");
            $upd->execute([$g['id']]);
            $g['updates'] = $upd->fetchAll();
        }

        jsonResponse(['grievances' => $grievances]);
        break;

    case 'create':
        $category = $_POST['category'] ?? 'other';
        $subject = sanitize($_POST['subject'] ?? '');
        $description = sanitize($_POST['description'] ?? '');
        $orderId = intval($_POST['order_id'] ?? 0) ?: null;
        $amountDisputed = floatval($_POST['amount_disputed'] ?? 0) ?: null;

        if (empty($description)) jsonResponse(['error' => 'Description is required'], 400);
        if (empty($subject)) $subject = $category;

        $categories = ['payment_delay','quality_rejection','pickup_noshow','price_dispute','fraud','other'];
        if (!in_array($category, $categories)) $category = 'other';

        $ticketCode = generateCode('TKT');
        $db->prepare("INSERT INTO grievances (ticket_code, filed_by, order_id, category, subject, description, amount_disputed, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'submitted')")
           ->execute([$ticketCode, $user['id'], $orderId, $category, $subject, $description, $amountDisputed]);
        $gId = $db->lastInsertId();

        // Create first update
        $db->prepare("INSERT INTO grievance_updates (grievance_id, update_by, update_text) VALUES (?, ?, ?)")
           ->execute([$gId, $user['id'], "Ticket submitted by " . $user['full_name'] . ". Awaiting review."]);

        // Notify user
        $db->prepare("INSERT INTO notifications (user_id, title, message, icon, notification_type) VALUES (?, '🛡️ Grievance Filed', ?, '🛡️', 'grievance')")
           ->execute([$user['id'], "Ticket $ticketCode has been submitted. Our team will review within 48 hours."]);

        jsonResponse(['success' => true, 'ticket_code' => $ticketCode]);
        break;

    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}
