<?php
// API: Buyer Offers
require_once __DIR__ . '/../auth/check.php';

$db = getDB();
$user = $_SESSION['user'];
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {

    case 'list':
        $mode = $_GET['mode'] ?? 'for_lot';
        if ($mode === 'for_lot') {
            // Offers on a specific lot (farmer view)
            $lotId = intval($_GET['lot_id'] ?? 0);
            $stmt = $db->prepare("
                SELECT bo.*, u.full_name AS buyer_name, up.firm_name, u.is_verified AS buyer_verified, up.rating
                FROM buyer_offers bo
                JOIN users u ON bo.buyer_id = u.id
                LEFT JOIN user_profiles up ON u.id = up.user_id
                WHERE bo.lot_id = ? AND bo.status = 'active'
                ORDER BY bo.offered_price DESC
            ");
            $stmt->execute([$lotId]);
        } elseif ($mode === 'my_offers') {
            // Offers I sent (buyer view)
            $stmt = $db->prepare("
                SELECT bo.*, fl.lot_code, c.name_en AS crop_name, c.icon AS crop_icon,
                       fl.quantity, fl.unit, u.full_name AS farmer_name
                FROM buyer_offers bo
                JOIN farmer_lots fl ON bo.lot_id = fl.id
                JOIN crops c ON fl.crop_id = c.id
                JOIN users u ON fl.farmer_id = u.id
                WHERE bo.buyer_id = ?
                ORDER BY bo.created_at DESC
            ");
            $stmt->execute([$user['id']]);
        } else {
            // All active offers for farmer's lots
            $stmt = $db->prepare("
                SELECT bo.*, u.full_name AS buyer_name, up.firm_name, u.is_verified AS buyer_verified, up.rating,
                       fl.lot_code, c.name_en AS crop_name, c.icon AS crop_icon, fl.quantity, fl.unit
                FROM buyer_offers bo
                JOIN users u ON bo.buyer_id = u.id
                LEFT JOIN user_profiles up ON u.id = up.user_id
                JOIN farmer_lots fl ON bo.lot_id = fl.id
                JOIN crops c ON fl.crop_id = c.id
                WHERE fl.farmer_id = ? AND bo.status = 'active'
                ORDER BY bo.offered_price DESC
            ");
            $stmt->execute([$user['id']]);
        }
        jsonResponse(['offers' => $stmt->fetchAll()]);
        break;

    case 'create':
        // Buyer makes offer on a lot
        if (!in_array($user['role'], ['buyer','merchant'])) {
            jsonResponse(['error' => 'Only buyers can make offers'], 403);
        }
        $lotId = intval($_POST['lot_id'] ?? 0);
        $offeredPrice = floatval($_POST['offered_price'] ?? 0);
        $quantity = floatval($_POST['quantity_requested'] ?? 0);
        $pickupTerms = sanitize($_POST['pickup_terms'] ?? '');
        $paymentTerms = sanitize($_POST['payment_terms'] ?? '');
        $validDays = intval($_POST['valid_days'] ?? 7);
        $message = sanitize($_POST['message'] ?? '');

        if ($lotId <= 0 || $offeredPrice <= 0 || $quantity <= 0) {
            jsonResponse(['error' => 'Lot, price, and quantity are required'], 400);
        }

        // Verify lot exists and is available
        $lot = $db->prepare("SELECT * FROM farmer_lots WHERE id = ? AND status IN ('available','in_bidding')");
        $lot->execute([$lotId]);
        $lotData = $lot->fetch();
        if (!$lotData) jsonResponse(['error' => 'Lot not available'], 404);

        $offerCode = generateCode('OFF');
        $validUntil = date('Y-m-d', strtotime("+$validDays days"));

        $stmt = $db->prepare("
            INSERT INTO buyer_offers (offer_code, buyer_id, lot_id, offered_price, quantity_requested,
                pickup_terms, payment_terms, valid_until, message, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
        ");
        $stmt->execute([$offerCode, $user['id'], $lotId, $offeredPrice, $quantity, $pickupTerms, $paymentTerms, $validUntil, $message]);

        // Update lot status and offer count
        $db->prepare("UPDATE farmer_lots SET status = 'in_bidding', offers_count = offers_count + 1 WHERE id = ?")
           ->execute([$lotId]);

        // Notify farmer
        $db->prepare("INSERT INTO notifications (user_id, title, message, icon, notification_type, link_section, link_id) VALUES (?, ?, ?, '🎉', 'offer_received', 'marketplace', ?)")
           ->execute([$lotData['farmer_id'], '🎉 New Offer Received!', $user['display_name'] . " offered ₹" . number_format($offeredPrice) . "/Q for your lot " . $lotData['lot_code'], $lotId]);

        jsonResponse(['success' => true, 'offer_code' => $offerCode]);
        break;

    case 'accept':
        $offerId = intval($_POST['offer_id'] ?? 0);
        $offer = $db->prepare("
            SELECT bo.*, fl.farmer_id, fl.lot_code, fl.crop_id
            FROM buyer_offers bo
            JOIN farmer_lots fl ON bo.lot_id = fl.id
            WHERE bo.id = ? AND fl.farmer_id = ?
        ");
        $offer->execute([$offerId, $user['id']]);
        $offerData = $offer->fetch();
        if (!$offerData) jsonResponse(['error' => 'Offer not found'], 404);

        $db->beginTransaction();
        try {
            // Update offer status
            $db->prepare("UPDATE buyer_offers SET status = 'accepted', accepted_at = NOW() WHERE id = ?")->execute([$offerId]);

            // Reject other active offers on the same lot
            $db->prepare("UPDATE buyer_offers SET status = 'rejected', rejection_reason = 'Another offer accepted' WHERE lot_id = ? AND id != ? AND status = 'active'")
               ->execute([$offerData['lot_id'], $offerId]);

            // Update lot status
            $db->prepare("UPDATE farmer_lots SET status = 'sold' WHERE id = ?")->execute([$offerData['lot_id']]);

            // Create order
            $orderCode = generateCode('ORD');
            $totalAmount = $offerData['offered_price'] * $offerData['quantity_requested'];
            $platformFee = round($totalAmount * PLATFORM_FEE_PERCENT / 100, 2);
            $netPayout = $totalAmount - $platformFee;

            $db->prepare("
                INSERT INTO orders (order_code, lot_id, offer_id, farmer_id, buyer_id, crop_id,
                    quantity, unit, agreed_price, total_amount, platform_fee_percent, platform_fee_amount,
                    net_farmer_payout, status, payment_status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'Quintal', ?, ?, ?, ?, ?, 'confirmed', 'escrow_deposited')
            ")->execute([
                $orderCode, $offerData['lot_id'], $offerId, $user['id'], $offerData['buyer_id'],
                $offerData['crop_id'], $offerData['quantity_requested'], $offerData['offered_price'],
                $totalAmount, PLATFORM_FEE_PERCENT, $platformFee, $netPayout
            ]);
            $orderId = $db->lastInsertId();

            // Create order timeline
            $timeline = [
                ['Offer Accepted', 'completed', 0],
                ['Pickup Scheduled', 'current', 1],
                ['Quality Verification', 'upcoming', 2],
                ['Bank Release', 'upcoming', 3]
            ];
            foreach ($timeline as $t) {
                $db->prepare("INSERT INTO order_timeline (order_id, step_title, status, sort_order, completed_at) VALUES (?, ?, ?, ?, ?)")
                   ->execute([$orderId, $t[0], $t[1], $t[2], $t[1] === 'completed' ? date('Y-m-d H:i:s') : null]);
            }

            // Create escrow deposit
            $db->prepare("INSERT INTO escrow_deposits (order_id, buyer_id, amount, status, deposited_at) VALUES (?, ?, ?, 'deposited', NOW())")
               ->execute([$orderId, $offerData['buyer_id'], $totalAmount]);

            // Create transaction record
            $txnCode = generateCode('TXN', 5);
            $db->prepare("INSERT INTO transactions (transaction_code, order_id, payer_id, payee_id, amount, transaction_type, status) VALUES (?, ?, ?, ?, ?, 'escrow_deposit', 'completed')")
               ->execute([$txnCode, $orderId, $offerData['buyer_id'], $user['id'], $totalAmount]);

            // Notify buyer
            $db->prepare("INSERT INTO notifications (user_id, title, message, icon, notification_type, link_section, link_id) VALUES (?, ?, ?, '✅', 'offer_accepted', 'payments', ?)")
               ->execute([$offerData['buyer_id'], '✅ Offer Accepted!', "Your offer on lot " . $offerData['lot_code'] . " has been accepted. Order: $orderCode", $orderId]);

            $db->commit();
            jsonResponse(['success' => true, 'order_code' => $orderCode, 'order_id' => $orderId]);
        } catch (Exception $e) {
            $db->rollBack();
            jsonResponse(['error' => 'Failed to accept offer: ' . $e->getMessage()], 500);
        }
        break;

    case 'counter':
        $offerId = intval($_POST['offer_id'] ?? 0);
        $counterPrice = floatval($_POST['counter_price'] ?? 0);
        $message = sanitize($_POST['message'] ?? '');

        if ($counterPrice <= 0) jsonResponse(['error' => 'Counter price is required'], 400);

        $offer = $db->prepare("
            SELECT bo.*, fl.farmer_id FROM buyer_offers bo
            JOIN farmer_lots fl ON bo.lot_id = fl.id
            WHERE bo.id = ?
        ");
        $offer->execute([$offerId]);
        $offerData = $offer->fetch();
        if (!$offerData) jsonResponse(['error' => 'Offer not found'], 404);

        // Determine from/to
        $fromUser = $user['id'];
        $toUser = ($user['id'] == $offerData['farmer_id']) ? $offerData['buyer_id'] : $offerData['farmer_id'];

        $db->prepare("INSERT INTO counter_offers (offer_id, from_user_id, to_user_id, counter_price, message) VALUES (?, ?, ?, ?, ?)")
           ->execute([$offerId, $fromUser, $toUser, $counterPrice, $message]);

        $db->prepare("UPDATE buyer_offers SET status = 'countered' WHERE id = ?")->execute([$offerId]);

        // Notify
        $db->prepare("INSERT INTO notifications (user_id, title, message, icon, notification_type) VALUES (?, ?, ?, '💬', 'counter_offer')")
           ->execute([$toUser, '💬 Counter Offer Received', "A counter offer of ₹" . number_format($counterPrice) . "/Q has been proposed."]);

        jsonResponse(['success' => true]);
        break;

    case 'reject':
        $offerId = intval($_POST['offer_id'] ?? 0);
        $reason = sanitize($_POST['reason'] ?? '');
        $db->prepare("UPDATE buyer_offers SET status = 'rejected', rejected_at = NOW(), rejection_reason = ? WHERE id = ? AND lot_id IN (SELECT id FROM farmer_lots WHERE farmer_id = ?)")
           ->execute([$reason, $offerId, $user['id']]);
        jsonResponse(['success' => true]);
        break;

    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}
