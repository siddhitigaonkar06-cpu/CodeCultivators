<?php
// API: Dashboard Summary Stats
require_once __DIR__ . '/../auth/check.php';

$db = getDB();
$user = $_SESSION['user'];

if ($user['role'] === 'farmer') {
    // Farmer dashboard stats
    $lotCount = $db->prepare("SELECT COUNT(*) FROM farmer_lots WHERE farmer_id = ? AND status IN ('available','in_bidding')");
    $lotCount->execute([$user['id']]);

    $lotNames = $db->prepare("
        SELECT c.name_en FROM farmer_lots fl JOIN crops c ON fl.crop_id = c.id
        WHERE fl.farmer_id = ? AND fl.status IN ('available','in_bidding')
        ORDER BY fl.created_at DESC LIMIT 5
    ");
    $lotNames->execute([$user['id']]);

    $offerCount = $db->prepare("
        SELECT COUNT(*) FROM buyer_offers bo
        JOIN farmer_lots fl ON bo.lot_id = fl.id
        WHERE fl.farmer_id = ? AND bo.status = 'active'
    ");
    $offerCount->execute([$user['id']]);

    $pendingPayout = $db->prepare("
        SELECT COALESCE(SUM(net_farmer_payout), 0)
        FROM orders WHERE farmer_id = ? AND payment_status IN ('escrow_deposited','escrow_released')
    ");
    $pendingPayout->execute([$user['id']]);

    $highestBid = $db->prepare("
        SELECT MAX(bo.offered_price) AS max_price, u.full_name AS buyer_name
        FROM buyer_offers bo
        JOIN farmer_lots fl ON bo.lot_id = fl.id
        JOIN users u ON bo.buyer_id = u.id
        WHERE fl.farmer_id = ? AND bo.status = 'active'
        GROUP BY bo.id ORDER BY bo.offered_price DESC LIMIT 1
    ");
    $highestBid->execute([$user['id']]);

    jsonResponse([
        'crop_count' => intval($lotCount->fetchColumn()),
        'crop_names' => array_column($lotNames->fetchAll(), 'name_en'),
        'offer_count' => intval($offerCount->fetchColumn()),
        'pending_payout' => floatval($pendingPayout->fetchColumn()),
        'highest_bid' => $highestBid->fetch() ?: null
    ]);

} else {
    // Buyer dashboard stats
    $reqCount = $db->prepare("SELECT COUNT(*) FROM buyer_requirements WHERE buyer_id = ? AND status = 'open'");
    $reqCount->execute([$user['id']]);

    $offerCount = $db->prepare("SELECT COUNT(*) FROM buyer_offers WHERE buyer_id = ? AND status = 'active'");
    $offerCount->execute([$user['id']]);

    $orderCount = $db->prepare("SELECT COUNT(*) FROM orders WHERE buyer_id = ? AND status NOT IN ('completed','cancelled')");
    $orderCount->execute([$user['id']]);

    $totalSpent = $db->prepare("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE buyer_id = ? AND status = 'completed'");
    $totalSpent->execute([$user['id']]);

    jsonResponse([
        'requirement_count' => intval($reqCount->fetchColumn()),
        'active_offers' => intval($offerCount->fetchColumn()),
        'active_orders' => intval($orderCount->fetchColumn()),
        'total_spent' => floatval($totalSpent->fetchColumn())
    ]);
}
