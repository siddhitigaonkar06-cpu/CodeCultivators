<?php
// API: Notifications
require_once __DIR__ . '/../auth/check.php';

$db = getDB();
$user = $_SESSION['user'];
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {

    case 'list':
        $limit = intval($_GET['limit'] ?? 20);
        $stmt = $db->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
        $stmt->execute([$user['id'], $limit]);
        $notifications = $stmt->fetchAll();

        $unread = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $unread->execute([$user['id']]);
        $unreadCount = $unread->fetchColumn();

        jsonResponse(['notifications' => $notifications, 'unread_count' => intval($unreadCount)]);
        break;

    case 'mark_read':
        $notifId = intval($_POST['id'] ?? 0);
        if ($notifId > 0) {
            $db->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?")->execute([$notifId, $user['id']]);
        } else {
            // Mark all as read
            $db->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$user['id']]);
        }
        jsonResponse(['success' => true]);
        break;

    case 'count':
        $unread = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $unread->execute([$user['id']]);
        jsonResponse(['unread_count' => intval($unread->fetchColumn())]);
        break;

    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}
