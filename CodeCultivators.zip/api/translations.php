<?php
// API: Translations - DB-backed i18n
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');

$lang = $_GET['lang'] ?? 'en';
if (!in_array($lang, SUPPORTED_LANGUAGES)) $lang = 'en';

$db = getDB();

// Get all translations for the requested language
$stmt = $db->prepare("
    SELECT tk.key_name, t.translated_text
    FROM translations t
    JOIN translation_keys tk ON t.key_id = tk.id
    WHERE t.language_code = ?
");
$stmt->execute([$lang]);
$rows = $stmt->fetchAll();

$dict = [];
foreach ($rows as $row) {
    $dict[$row['key_name']] = $row['translated_text'];
}

// If not English, fill missing keys with English
if ($lang !== 'en' && count($dict) < 50) {
    $enStmt = $db->prepare("
        SELECT tk.key_name, t.translated_text
        FROM translations t
        JOIN translation_keys tk ON t.key_id = tk.id
        WHERE t.language_code = 'en'
    ");
    $enStmt->execute();
    foreach ($enStmt->fetchAll() as $row) {
        if (!isset($dict[$row['key_name']])) {
            $dict[$row['key_name']] = $row['translated_text'];
        }
    }
}

// Get language labels
$langs = $db->query("SELECT code, name_english, name_native, flag_emoji, direction FROM supported_languages WHERE is_active = 1 ORDER BY sort_order")->fetchAll();

echo json_encode([
    'language' => $lang,
    'translations' => $dict,
    'supported_languages' => $langs
], JSON_UNESCAPED_UNICODE);
