<?php
// API: Buyer Requirements
require_once __DIR__ . '/../auth/check.php';

$db = getDB();
$user = $_SESSION['user'];
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {

    case 'list':
        $mode = $_GET['mode'] ?? 'my';
        if ($mode === 'all') {
            // All open requirements (farmer view)
            $stmt = $db->query("
                SELECT br.*, c.name_en AS crop_name, c.icon, u.full_name AS buyer_name, u.is_verified, up.firm_name
                FROM buyer_requirements br
                JOIN crops c ON br.crop_id = c.id
                JOIN users u ON br.buyer_id = u.id
                LEFT JOIN user_profiles up ON u.id = up.user_id
                WHERE br.status = 'open'
                ORDER BY br.created_at DESC
            ");
        } else {
            // My requirements (buyer view)
            $stmt = $db->prepare("
                SELECT br.*, c.name_en AS crop_name, c.icon
                FROM buyer_requirements br
                JOIN crops c ON br.crop_id = c.id
                WHERE br.buyer_id = ?
                ORDER BY br.created_at DESC
            ");
            $stmt->execute([$user['id']]);
        }
        jsonResponse(['requirements' => $stmt->fetchAll()]);
        break;

    case 'create':
        if (!in_array($user['role'], ['buyer','merchant'])) {
            jsonResponse(['error' => 'Only buyers can post requirements'], 403);
        }

        $cropId = intval($_POST['crop_id'] ?? 0);
        $quantity = floatval($_POST['quantity_needed'] ?? 0);
        $unit = in_array($_POST['unit'] ?? '', ['Quintal','Kg','Ton','Bag']) ? $_POST['unit'] : 'Quintal';
        $minPrice = floatval($_POST['min_price'] ?? 0) ?: null;
        $maxPrice = floatval($_POST['max_price'] ?? 0) ?: null;
        $gradeRequired = sanitize($_POST['grade_required'] ?? '');
        $deliveryLocation = sanitize($_POST['delivery_location'] ?? '');
        $deliveryDeadline = $_POST['delivery_deadline'] ?? null;
        $description = sanitize($_POST['description'] ?? '');

        if ($cropId <= 0 || $quantity <= 0) {
            jsonResponse(['error' => 'Crop and quantity are required'], 400);
        }

        $reqCode = generateCode('REQ');
        $db->prepare("INSERT INTO buyer_requirements (requirement_code, buyer_id, crop_id, quantity_needed, unit, min_price, max_price, grade_required, delivery_location, delivery_deadline, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
           ->execute([$reqCode, $user['id'], $cropId, $quantity, $unit, $minPrice, $maxPrice, $gradeRequired, $deliveryLocation, $deliveryDeadline, $description]);

        jsonResponse(['success' => true, 'requirement_code' => $reqCode]);
        break;

    case 'matching_lots':
        // Find farmer lots matching a requirement
        $reqId = intval($_GET['requirement_id'] ?? 0);
        $req = $db->prepare("SELECT * FROM buyer_requirements WHERE id = ?");
        $req->execute([$reqId]);
        $reqData = $req->fetch();
        if (!$reqData) jsonResponse(['error' => 'Requirement not found'], 404);

        $stmt = $db->prepare("
            SELECT fl.*, c.name_en AS crop_name, c.icon AS crop_icon,
                   u.full_name AS farmer_name, u.phone AS farmer_phone, u.is_verified
            FROM farmer_lots fl
            JOIN crops c ON fl.crop_id = c.id
            JOIN users u ON fl.farmer_id = u.id
            WHERE fl.crop_id = ? AND fl.status IN ('available','in_bidding')
            ORDER BY fl.expected_price ASC
        ");
        $stmt->execute([$reqData['crop_id']]);
        jsonResponse(['matching_lots' => $stmt->fetchAll()]);
        break;

    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}
