<?php
// API: Logistics - Warehouses & Transporters
require_once __DIR__ . '/../auth/check.php';

$db = getDB();
$user = $_SESSION['user'];
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {

    case 'list':
        $warehouses = $db->query("SELECT * FROM warehouses WHERE is_active = 1 ORDER BY name")->fetchAll();
        $transporters = $db->query("SELECT * FROM transporters WHERE is_active = 1 ORDER BY rating DESC")->fetchAll();
        jsonResponse(['warehouses' => $warehouses, 'transporters' => $transporters]);
        break;

    case 'book_storage':
        $warehouseId = intval($_POST['warehouse_id'] ?? 0);
        $lotId = intval($_POST['lot_id'] ?? 0) ?: null;
        $quantity = floatval($_POST['quantity'] ?? 0);
        $startDate = $_POST['start_date'] ?? date('Y-m-d');

        if ($warehouseId <= 0 || $quantity <= 0) {
            jsonResponse(['error' => 'Warehouse and quantity required'], 400);
        }

        $bookingCode = generateCode('WB');
        $db->prepare("INSERT INTO warehouse_bookings (booking_code, warehouse_id, user_id, lot_id, quantity_quintals, start_date, status) VALUES (?, ?, ?, ?, ?, ?, 'requested')")
           ->execute([$bookingCode, $warehouseId, $user['id'], $lotId, $quantity, $startDate]);

        $db->prepare("INSERT INTO notifications (user_id, title, message, icon, notification_type) VALUES (?, '🏬 Storage Booked', ?, '🏬', 'system')")
           ->execute([$user['id'], "Warehouse booking $bookingCode submitted. You'll receive confirmation shortly."]);

        jsonResponse(['success' => true, 'booking_code' => $bookingCode]);
        break;

    case 'book_transport':
        $transporterId = intval($_POST['transporter_id'] ?? 0);
        $pickupAddress = sanitize($_POST['pickup_address'] ?? '');
        $deliveryAddress = sanitize($_POST['delivery_address'] ?? '');
        $pickupDatetime = $_POST['pickup_datetime'] ?? null;
        $orderId = intval($_POST['order_id'] ?? 0) ?: null;
        $lotId = intval($_POST['lot_id'] ?? 0) ?: null;

        if ($transporterId <= 0 || empty($pickupAddress) || empty($deliveryAddress)) {
            jsonResponse(['error' => 'Transporter, pickup and delivery addresses required'], 400);
        }

        $bookingCode = generateCode('TB');
        $db->prepare("INSERT INTO transport_bookings (booking_code, transporter_id, user_id, order_id, lot_id, pickup_address, delivery_address, pickup_datetime, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'requested')")
           ->execute([$bookingCode, $transporterId, $user['id'], $orderId, $lotId, $pickupAddress, $deliveryAddress, $pickupDatetime]);

        $db->prepare("INSERT INTO notifications (user_id, title, message, icon, notification_type) VALUES (?, '🚛 Transport Booked', ?, '🚛', 'system')")
           ->execute([$user['id'], "Transport booking $bookingCode submitted. Driver details will be shared soon."]);

        jsonResponse(['success' => true, 'booking_code' => $bookingCode]);
        break;

    case 'my_bookings':
        $whBookings = $db->prepare("
            SELECT wb.*, w.name AS warehouse_name, w.warehouse_type
            FROM warehouse_bookings wb JOIN warehouses w ON wb.warehouse_id = w.id
            WHERE wb.user_id = ? ORDER BY wb.created_at DESC
        ");
        $whBookings->execute([$user['id']]);

        $trBookings = $db->prepare("
            SELECT tb.*, t.provider_name, t.vehicle_type
            FROM transport_bookings tb JOIN transporters t ON tb.transporter_id = t.id
            WHERE tb.user_id = ? ORDER BY tb.created_at DESC
        ");
        $trBookings->execute([$user['id']]);

        jsonResponse(['warehouse_bookings' => $whBookings->fetchAll(), 'transport_bookings' => $trBookings->fetchAll()]);
        break;

    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}
