<?php
// API: Farmer Lots CRUD
require_once __DIR__ . '/../auth/check.php';

$db = getDB();
$user = $_SESSION['user'];
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {

    case 'list':
        // My lots (farmer) or marketplace (all available lots)
        $mode = $_GET['mode'] ?? 'my';
        if ($mode === 'marketplace') {
            $stmt = $db->query("
                SELECT fl.*, c.name_en AS crop_name, c.icon AS crop_icon, c.slug AS crop_slug,
                       cg.grade_name, cg.grade_label,
                       u.full_name AS farmer_name, u.phone AS farmer_phone, u.is_verified AS farmer_verified,
                       (SELECT image_url FROM lot_images WHERE lot_id = fl.id AND is_primary = 1 LIMIT 1) AS image_url,
                       (SELECT ci.image_url FROM crop_images ci WHERE ci.crop_id = fl.crop_id AND ci.is_specimen = 1 LIMIT 1) AS specimen_image
                FROM farmer_lots fl
                JOIN crops c ON fl.crop_id = c.id
                LEFT JOIN crop_grades cg ON fl.grade_id = cg.id
                JOIN users u ON fl.farmer_id = u.id
                WHERE fl.status IN ('available','in_bidding')
                ORDER BY fl.created_at DESC
            ");
        } else {
            $stmt = $db->prepare("
                SELECT fl.*, c.name_en AS crop_name, c.icon AS crop_icon, c.slug AS crop_slug,
                       cg.grade_name, cg.grade_label,
                       (SELECT image_url FROM lot_images WHERE lot_id = fl.id AND is_primary = 1 LIMIT 1) AS image_url,
                       (SELECT ci.image_url FROM crop_images ci WHERE ci.crop_id = fl.crop_id AND ci.is_specimen = 1 LIMIT 1) AS specimen_image
                FROM farmer_lots fl
                JOIN crops c ON fl.crop_id = c.id
                LEFT JOIN crop_grades cg ON fl.grade_id = cg.id
                WHERE fl.farmer_id = ?
                ORDER BY fl.created_at DESC
            ");
            $stmt->execute([$user['id']]);
        }
        jsonResponse(['lots' => $stmt->fetchAll()]);
        break;

    case 'create':
        if ($user['role'] !== 'farmer') jsonResponse(['error' => 'Only farmers can create lots'], 403);

        $cropId = intval($_POST['crop_id'] ?? 0);
        $gradeId = intval($_POST['grade_id'] ?? 0) ?: null;
        $quantity = floatval($_POST['quantity'] ?? 0);
        $unit = in_array($_POST['unit'] ?? '', ['Quintal','Kg','Ton','Bag']) ? $_POST['unit'] : 'Quintal';
        $expectedPrice = floatval($_POST['expected_price'] ?? 0);
        $harvestDate = $_POST['harvest_date'] ?? null;
        $description = sanitize($_POST['description'] ?? '');
        $qualitySpecs = sanitize($_POST['quality_specs'] ?? '');
        $moisture = floatval($_POST['moisture_percent'] ?? 0) ?: null;
        $foreignMatter = floatval($_POST['foreign_matter_percent'] ?? 0) ?: null;
        $pickupLocation = sanitize($_POST['pickup_location'] ?? '');
        $contactPhone = sanitize($_POST['contact_phone'] ?? $user['phone']);

        if ($cropId <= 0 || $quantity <= 0 || $expectedPrice <= 0) {
            jsonResponse(['error' => 'Crop, quantity, and price are required'], 400);
        }

        // Get mandi ref price
        $refStmt = $db->prepare("SELECT modal_price FROM mandi_prices WHERE crop_id = ? ORDER BY price_date DESC LIMIT 1");
        $refStmt->execute([$cropId]);
        $refPrice = $refStmt->fetchColumn() ?: null;

        $lotCode = generateCode('LOT');
        $stmt = $db->prepare("
            INSERT INTO farmer_lots (lot_code, farmer_id, crop_id, grade_id, quantity, unit,
                expected_price, mandi_ref_price, harvest_date, description, quality_specs,
                moisture_percent, foreign_matter_percent, pickup_location_text, contact_phone, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'available')
        ");
        $stmt->execute([
            $lotCode, $user['id'], $cropId, $gradeId, $quantity, $unit,
            $expectedPrice, $refPrice, $harvestDate, $description, $qualitySpecs,
            $moisture, $foreignMatter, $pickupLocation, $contactPhone
        ]);
        $lotId = $db->lastInsertId();

        // Handle uploaded image
        if (!empty($_POST['image_url'])) {
            $db->prepare("INSERT INTO lot_images (lot_id, image_url, is_primary) VALUES (?, ?, 1)")
               ->execute([$lotId, sanitize($_POST['image_url'])]);
        }

        // Create notification for the farmer
        $db->prepare("INSERT INTO notifications (user_id, title, message, icon, notification_type, link_section) VALUES (?, ?, ?, '🌾', 'system', 'my-crops')")
           ->execute([$user['id'], '🎉 Lot Published!', "Your lot $lotCode has been published to buyers."]);

        jsonResponse(['success' => true, 'lot_id' => $lotId, 'lot_code' => $lotCode]);
        break;

    case 'update_status':
        $lotId = intval($_POST['lot_id'] ?? 0);
        $status = $_POST['status'] ?? '';
        if (!in_array($status, ['available','in_bidding','sold','expired','withdrawn'])) {
            jsonResponse(['error' => 'Invalid status'], 400);
        }
        $db->prepare("UPDATE farmer_lots SET status = ? WHERE id = ? AND farmer_id = ?")
           ->execute([$status, $lotId, $user['id']]);
        jsonResponse(['success' => true]);
        break;

    case 'get':
        $lotId = intval($_GET['id'] ?? 0);
        $stmt = $db->prepare("
            SELECT fl.*, c.name_en AS crop_name, c.icon AS crop_icon,
                   cg.grade_name, cg.grade_label,
                   u.full_name AS farmer_name, u.phone AS farmer_phone
            FROM farmer_lots fl
            JOIN crops c ON fl.crop_id = c.id
            LEFT JOIN crop_grades cg ON fl.grade_id = cg.id
            JOIN users u ON fl.farmer_id = u.id
            WHERE fl.id = ?
        ");
        $stmt->execute([$lotId]);
        $lot = $stmt->fetch();
        if (!$lot) jsonResponse(['error' => 'Lot not found'], 404);

        // Images
        $imgs = $db->prepare("SELECT * FROM lot_images WHERE lot_id = ? ORDER BY sort_order");
        $imgs->execute([$lotId]);
        $lot['images'] = $imgs->fetchAll();

        jsonResponse(['lot' => $lot]);
        break;

    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}
