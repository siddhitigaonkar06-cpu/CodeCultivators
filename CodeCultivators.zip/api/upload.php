<?php
// API: File Upload Handler
require_once __DIR__ . '/../auth/check.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'POST required'], 405);
}

if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    jsonResponse(['error' => 'No file uploaded or upload error'], 400);
}

$file = $_FILES['image'];
$mime = mime_content_type($file['tmp_name']);

if (!in_array($mime, ALLOWED_IMAGE_TYPES)) {
    jsonResponse(['error' => 'Invalid file type. Allowed: JPEG, PNG, WebP, GIF'], 400);
}

if ($file['size'] > MAX_UPLOAD_SIZE) {
    jsonResponse(['error' => 'File too large. Max: ' . (MAX_UPLOAD_SIZE / 1024 / 1024) . 'MB'], 400);
}

// Generate unique filename
$ext = pathinfo($file['name'], PATHINFO_EXTENSION) ?: 'jpg';
$filename = 'img_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
$targetPath = UPLOAD_DIR . '/' . $filename;

if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
    jsonResponse(['error' => 'Failed to save file'], 500);
}

$imageUrl = UPLOAD_URL . '/' . $filename;

jsonResponse(['success' => true, 'image_url' => $imageUrl, 'filename' => $filename]);
