<?php
// API: Crops catalog, mandi prices, price history
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');
$db = getDB();
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {

    case 'list':
        $stmt = $db->query("
            SELECT c.id, c.slug, c.name_en, c.name_hi, c.name_local, c.icon,
                   c.msp_price, c.default_price_unit, c.moisture_max_percent, c.specimen_image_url,
                   cc.name AS category_name, cc.icon AS category_icon
            FROM crops c
            JOIN crop_categories cc ON c.category_id = cc.id
            WHERE c.is_active = 1
            ORDER BY c.sort_order, c.name_en
        ");
        $crops = $stmt->fetchAll();

        // Attach latest mandi price + change for each crop
        foreach ($crops as &$crop) {
            $priceStmt = $db->prepare("
                SELECT mp.modal_price, mp.change_percent, ml.name AS mandi_name
                FROM mandi_prices mp
                JOIN mandi_list ml ON mp.mandi_id = ml.id
                WHERE mp.crop_id = ?
                ORDER BY mp.price_date DESC
                LIMIT 1
            ");
            $priceStmt->execute([$crop['id']]);
            $latestPrice = $priceStmt->fetch();
            $crop['avg_mandi_price'] = $latestPrice ? floatval($latestPrice['modal_price']) : 0;
            $crop['change_24h'] = $latestPrice ? floatval($latestPrice['change_percent']) : 0;
            $crop['ref_mandi'] = $latestPrice ? $latestPrice['mandi_name'] : '';

            // Grades
            $gradeStmt = $db->prepare("SELECT id, grade_name, grade_label, description_en FROM crop_grades WHERE crop_id = ? ORDER BY sort_order");
            $gradeStmt->execute([$crop['id']]);
            $crop['grades'] = $gradeStmt->fetchAll();
        }

        jsonResponse(['crops' => $crops]);
        break;

    case 'categories':
        $stmt = $db->query("SELECT * FROM crop_categories WHERE is_active = 1 ORDER BY sort_order");
        jsonResponse(['categories' => $stmt->fetchAll()]);
        break;

    case 'mandi_prices':
        $cropId = intval($_GET['crop_id'] ?? 0);
        $stmt = $db->prepare("
            SELECT ml.id AS mandi_id, ml.name, ml.state, ml.district,
                   mp.modal_price, mp.min_price, mp.max_price, mp.change_percent, mp.price_date
            FROM mandi_list ml
            LEFT JOIN mandi_prices mp ON ml.id = mp.mandi_id AND mp.crop_id = ? AND mp.price_date = (
                SELECT MAX(price_date) FROM mandi_prices WHERE mandi_id = ml.id AND crop_id = ?
            )
            WHERE ml.is_active = 1
            ORDER BY ml.name
        ");
        $stmt->execute([$cropId, $cropId]);
        jsonResponse(['mandis' => $stmt->fetchAll()]);
        break;

    case 'mandi_matrix':
        // Returns all mandis with latest prices for all crops
        $mandis = $db->query("SELECT id, name, state, district FROM mandi_list WHERE is_active = 1 ORDER BY name")->fetchAll();
        $crops = $db->query("SELECT id, slug, name_en, icon FROM crops WHERE is_active = 1 ORDER BY sort_order")->fetchAll();

        foreach ($mandis as &$mandi) {
            $mandi['prices'] = [];
            foreach ($crops as $crop) {
                $ps = $db->prepare("SELECT modal_price FROM mandi_prices WHERE mandi_id = ? AND crop_id = ? ORDER BY price_date DESC LIMIT 1");
                $ps->execute([$mandi['id'], $crop['id']]);
                $p = $ps->fetch();
                $mandi['prices'][$crop['slug']] = $p ? floatval($p['modal_price']) : null;
            }
        }
        jsonResponse(['mandis' => $mandis, 'crops' => $crops]);
        break;

    case 'price_history':
        $cropId = intval($_GET['crop_id'] ?? 0);
        $mandiId = intval($_GET['mandi_id'] ?? 0);
        $days = intval($_GET['days'] ?? 7);

        $where = "WHERE mph.crop_id = ?";
        $params = [$cropId];
        if ($mandiId > 0) {
            $where .= " AND mph.mandi_id = ?";
            $params[] = $mandiId;
        }

        $stmt = $db->prepare("
            SELECT DATE_FORMAT(mph.price_date, '%d %b') AS date_label, mph.price_date,
                   AVG(mph.modal_price) AS price
            FROM mandi_price_history mph
            $where
            AND mph.price_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
            GROUP BY mph.price_date
            ORDER BY mph.price_date ASC
        ");
        $params[] = $days;
        $stmt->execute($params);
        jsonResponse(['history' => $stmt->fetchAll()]);
        break;

    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}
