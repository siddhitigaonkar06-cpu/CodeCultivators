<?php
// API: FPO Hub
require_once __DIR__ . '/../auth/check.php';

$db = getDB();
$user = $_SESSION['user'];
$action = $_GET['action'] ?? $_POST['action'] ?? 'my_fpo';

switch ($action) {

    case 'my_fpo':
        // Get FPO the user belongs to
        $stmt = $db->prepare("
            SELECT fo.*, fm.member_role
            FROM fpo_members fm
            JOIN fpo_organizations fo ON fm.fpo_id = fo.id
            WHERE fm.user_id = ? AND fm.status = 'active'
            LIMIT 1
        ");
        $stmt->execute([$user['id']]);
        $fpo = $stmt->fetch();

        if (!$fpo) {
            jsonResponse(['fpo' => null, 'message' => 'You are not a member of any FPO.']);
        }

        // Collective produce
        $produce = $db->prepare("
            SELECT fcp.*, c.name_en AS crop_name, c.icon
            FROM fpo_collective_produce fcp
            JOIN crops c ON fcp.crop_id = c.id
            WHERE fcp.fpo_id = ?
        ");
        $produce->execute([$fpo['id']]);
        $fpo['collective_produce'] = $produce->fetchAll();

        // Members
        $members = $db->prepare("
            SELECT fm.*, u.full_name, u.phone
            FROM fpo_members fm
            JOIN users u ON fm.user_id = u.id
            WHERE fm.fpo_id = ? AND fm.status = 'active'
            ORDER BY FIELD(fm.member_role, 'chairman','director','secretary','treasurer','member')
        ");
        $members->execute([$fpo['id']]);
        $fpo['members'] = $members->fetchAll();

        // Tenders
        $tenders = $db->prepare("
            SELECT ft.*, c.name_en AS crop_name, c.icon, u.full_name AS buyer_name
            FROM fpo_tenders ft
            JOIN crops c ON ft.crop_id = c.id
            JOIN users u ON ft.buyer_id = u.id
            WHERE ft.status IN ('open','bidding')
            ORDER BY ft.deadline ASC
        ");
        $tenders->execute();
        $fpo['tenders'] = $tenders->fetchAll();

        jsonResponse(['fpo' => $fpo]);
        break;

    case 'submit_bid':
        $tenderId = intval($_POST['tender_id'] ?? 0);
        $bidPrice = floatval($_POST['bid_price'] ?? 0);
        $quantityOffered = floatval($_POST['quantity_offered'] ?? 0);
        $message = sanitize($_POST['message'] ?? '');

        // Get user's FPO
        $fpo = $db->prepare("SELECT fpo_id FROM fpo_members WHERE user_id = ? AND status = 'active' AND member_role IN ('chairman','director') LIMIT 1");
        $fpo->execute([$user['id']]);
        $fpoData = $fpo->fetch();
        if (!$fpoData) jsonResponse(['error' => 'Only FPO directors/chairman can submit bids'], 403);

        $db->prepare("INSERT INTO fpo_bids (tender_id, fpo_id, bid_price, quantity_offered, message) VALUES (?, ?, ?, ?, ?)")
           ->execute([$tenderId, $fpoData['fpo_id'], $bidPrice, $quantityOffered, $message]);

        $db->prepare("UPDATE fpo_tenders SET status = 'bidding' WHERE id = ? AND status = 'open'")->execute([$tenderId]);

        jsonResponse(['success' => true]);
        break;

    case 'list_all':
        $fpos = $db->query("SELECT * FROM fpo_organizations WHERE is_active = 1 ORDER BY name")->fetchAll();
        jsonResponse(['fpos' => $fpos]);
        break;

    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}
