<?php
// API: Orders Management
require_once __DIR__ . '/../auth/check.php';

$db = getDB();
$user = $_SESSION['user'];
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {

    case 'list':
        $role = $user['role'];
        $userField = ($role === 'farmer') ? 'o.farmer_id' : 'o.buyer_id';

        $stmt = $db->prepare("
            SELECT o.*, c.name_en AS crop_name, c.icon AS crop_icon,
                   fu.full_name AS farmer_name, bu.full_name AS buyer_name,
                   bu.phone AS buyer_phone, fu.phone AS farmer_phone
            FROM orders o
            JOIN crops c ON o.crop_id = c.id
            JOIN users fu ON o.farmer_id = fu.id
            JOIN users bu ON o.buyer_id = bu.id
            WHERE $userField = ?
            ORDER BY o.created_at DESC
        ");
        $stmt->execute([$user['id']]);
        $orders = $stmt->fetchAll();

        // Attach timeline
        foreach ($orders as &$order) {
            $ts = $db->prepare("SELECT * FROM order_timeline WHERE order_id = ? ORDER BY sort_order");
            $ts->execute([$order['id']]);
            $order['timeline'] = $ts->fetchAll();
        }

        jsonResponse(['orders' => $orders]);
        break;

    case 'get':
        $orderId = intval($_GET['id'] ?? 0);
        $stmt = $db->prepare("
            SELECT o.*, c.name_en AS crop_name, c.icon AS crop_icon,
                   fu.full_name AS farmer_name, bu.full_name AS buyer_name,
                   fup.firm_name AS buyer_firm,
                   (SELECT upi_id FROM user_bank_details WHERE user_id = o.farmer_id AND is_primary = 1 LIMIT 1) AS farmer_upi
            FROM orders o
            JOIN crops c ON o.crop_id = c.id
            JOIN users fu ON o.farmer_id = fu.id
            JOIN users bu ON o.buyer_id = bu.id
            LEFT JOIN user_profiles fup ON bu.id = fup.user_id
            WHERE o.id = ? AND (o.farmer_id = ? OR o.buyer_id = ?)
        ");
        $stmt->execute([$orderId, $user['id'], $user['id']]);
        $order = $stmt->fetch();
        if (!$order) jsonResponse(['error' => 'Order not found'], 404);

        // Timeline
        $ts = $db->prepare("SELECT * FROM order_timeline WHERE order_id = ? ORDER BY sort_order");
        $ts->execute([$orderId]);
        $order['timeline'] = $ts->fetchAll();

        // Transactions
        $txs = $db->prepare("SELECT * FROM transactions WHERE order_id = ? ORDER BY created_at");
        $txs->execute([$orderId]);
        $order['transactions'] = $txs->fetchAll();

        jsonResponse(['order' => $order]);
        break;

    case 'update_timeline':
        $orderId = intval($_POST['order_id'] ?? 0);
        $stepId = intval($_POST['step_id'] ?? 0);
        $status = $_POST['status'] ?? '';

        if (!in_array($status, ['completed','current','upcoming'])) {
            jsonResponse(['error' => 'Invalid status'], 400);
        }

        // Verify ownership
        $order = $db->prepare("SELECT * FROM orders WHERE id = ? AND (farmer_id = ? OR buyer_id = ?)");
        $order->execute([$orderId, $user['id'], $user['id']]);
        if (!$order->fetch()) jsonResponse(['error' => 'Order not found'], 404);

        $db->prepare("UPDATE order_timeline SET status = ?, completed_at = ? WHERE id = ? AND order_id = ?")
           ->execute([$status, $status === 'completed' ? date('Y-m-d H:i:s') : null, $stepId, $orderId]);

        // If all steps completed, mark order as completed
        $pending = $db->prepare("SELECT COUNT(*) FROM order_timeline WHERE order_id = ? AND status != 'completed'");
        $pending->execute([$orderId]);
        if ($pending->fetchColumn() == 0) {
            $db->prepare("UPDATE orders SET status = 'completed', payment_status = 'paid_out', completed_at = NOW() WHERE id = ?")->execute([$orderId]);
        }

        jsonResponse(['success' => true]);
        break;

    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}
