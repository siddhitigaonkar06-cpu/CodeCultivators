<?php
require_once __DIR__ . '/../auth/check.php';
if (!in_array($user['role'] ?? $_SESSION['user']['role'], ['buyer','merchant','admin'])) {
    header('Location: ' . APP_BASE_URL . '/farmer_kisan_setu.PHP');
    exit;
}
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Merchant Portal - KisanSetu</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        .merchant-header {
            background: linear-gradient(135deg, #0284c7, #0369a1);
            color: white; padding: 24px; border-radius: var(--radius-lg);
            margin-bottom: 24px; box-shadow: var(--shadow-lg);
        }
        .merchant-header h1 { font-size: 24px; font-weight: 800; }
        .merchant-header p { opacity: 0.9; font-size: 14px; margin-top: 4px; }
        .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: white; border: 1px solid var(--border); border-radius: var(--radius-md); padding: 20px; }
        .stat-card .stat-value { font-size: 28px; font-weight: 800; color: var(--primary-dark); }
        .stat-card .stat-label { font-size: 13px; color: var(--text-muted); font-weight: 600; }
        .tab-bar { display: flex; gap: 8px; margin-bottom: 20px; overflow-x: auto; }
        .tab-btn {
            padding: 10px 18px; border: 2px solid var(--border); border-radius: var(--radius-full);
            background: white; font-weight: 700; font-size: 14px; cursor: pointer;
            white-space: nowrap; transition: all 0.2s;
        }
        .tab-btn.active { background: var(--primary); color: white; border-color: var(--primary); }
        .tab-btn:hover { border-color: var(--primary); }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .item-card {
            background: white; border: 1px solid var(--border); border-radius: var(--radius-sm);
            padding: 16px; margin-bottom: 12px; transition: all 0.2s;
        }
        .item-card:hover { box-shadow: var(--shadow-md); }
        .empty-state {
            text-align: center; padding: 40px; color: var(--text-muted);
            font-size: 16px; font-weight: 600;
        }
        .empty-state .empty-icon { font-size: 48px; margin-bottom: 12px; }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="app-header">
        <div class="header-container">
            <div class="brand-logo" onclick="location.href='dashboard.php'">
                <div class="brand-icon">🌾</div>
                <div class="brand-title">
                    <span>KisanSetu</span>
                    <span class="brand-subtitle">Merchant Portal</span>
                </div>
            </div>
            <div class="header-actions">
                <span style="font-weight:700; color:var(--text-muted);">💼 <?= htmlspecialchars($user['display_name']) ?></span>
                <a href="<?= APP_BASE_URL ?>/auth/logout.php" class="btn btn-secondary btn-sm">Logout</a>
            </div>
        </div>
    </header>

    <main class="main-wrapper">
        <div class="merchant-header">
            <h1>💼 Merchant Procurement Dashboard</h1>
            <p>Welcome, <?= htmlspecialchars($user['display_name']) ?> — Manage your procurement, offers, and orders.</p>
        </div>

        <!-- Stats -->
        <div class="stat-grid" id="merchant-stats">
            <div class="stat-card">
                <div class="stat-label">📌 Active Requirements</div>
                <div class="stat-value" id="stat-requirements">—</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">📩 Active Offers Sent</div>
                <div class="stat-value" id="stat-offers">—</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">📦 Active Orders</div>
                <div class="stat-value" id="stat-orders">—</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">💰 Total Procurement Spend</div>
                <div class="stat-value" id="stat-spent">—</div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="tab-bar">
            <button class="tab-btn active" onclick="showTab('browse')">🌾 Browse Farmer Lots</button>
            <button class="tab-btn" onclick="showTab('requirements')">📌 My Requirements</button>
            <button class="tab-btn" onclick="showTab('offers')">📩 My Offers</button>
            <button class="tab-btn" onclick="showTab('orders')">📦 Orders</button>
            <button class="tab-btn" onclick="showTab('post')">➕ Post Requirement</button>
        </div>

        <!-- Tab: Browse Lots -->
        <div class="tab-content active" id="tab-browse">
            <div class="section-title-bar">
                <h3 class="section-title">🌾 Available Farmer Lots</h3>
            </div>
            <div id="browse-lots-list"></div>
        </div>

        <!-- Tab: My Requirements -->
        <div class="tab-content" id="tab-requirements">
            <div class="section-title-bar">
                <h3 class="section-title">📌 Your Posted Requirements</h3>
            </div>
            <div id="my-requirements-list"></div>
        </div>

        <!-- Tab: My Offers -->
        <div class="tab-content" id="tab-offers">
            <div class="section-title-bar">
                <h3 class="section-title">📩 Offers You've Sent</h3>
            </div>
            <div id="my-offers-list"></div>
        </div>

        <!-- Tab: Orders -->
        <div class="tab-content" id="tab-orders">
            <div class="section-title-bar">
                <h3 class="section-title">📦 Your Orders</h3>
            </div>
            <div id="my-orders-list"></div>
        </div>

        <!-- Tab: Post Requirement -->
        <div class="tab-content" id="tab-post">
            <div class="card" style="max-width:600px;">
                <h3 style="font-weight:800; margin-bottom:16px;">➕ Post Crop Procurement Requirement</h3>
                <form id="post-req-form">
                    <div class="form-group">
                        <label class="form-label">Crop Needed *</label>
                        <select id="req-crop" class="form-select" required></select>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                        <div class="form-group">
                            <label class="form-label">Quantity Needed *</label>
                            <input type="number" id="req-quantity" class="form-input" placeholder="e.g. 100" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Unit</label>
                            <select id="req-unit" class="form-select">
                                <option value="Quintal">Quintal</option>
                                <option value="Ton">Ton</option>
                                <option value="Kg">Kg</option>
                            </select>
                        </div>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                        <div class="form-group">
                            <label class="form-label">Min Price (₹)</label>
                            <input type="number" id="req-min-price" class="form-input" placeholder="e.g. 2000">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Max Price (₹)</label>
                            <input type="number" id="req-max-price" class="form-input" placeholder="e.g. 2500">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Grade Required</label>
                        <input type="text" id="req-grade" class="form-input" placeholder="e.g. Grade A / B">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Delivery Location</label>
                        <input type="text" id="req-delivery" class="form-input" placeholder="Delivery address or depot">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Description / Notes</label>
                        <textarea id="req-description" class="form-textarea" rows="3" placeholder="Additional details..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full">📌 Post Requirement</button>
                </form>
            </div>
        </div>
    </main>

    <!-- Make Offer Modal -->
    <div class="modal-overlay" id="modal-offer">
        <div class="modal-card">
            <div class="modal-header">
                <h3 class="modal-title">📩 Make Offer to Farmer</h3>
                <button class="modal-close-btn" onclick="closeModal('modal-offer')">✕</button>
            </div>
            <div id="offer-lot-info" style="background:var(--surface-bg); padding:12px; border-radius:var(--radius-sm); margin-bottom:16px;"></div>
            <div class="form-group">
                <label class="form-label">Your Offered Price (₹ / Quintal) *</label>
                <input type="number" id="offer-price" class="form-input" style="font-size:20px; font-weight:800;">
            </div>
            <div class="form-group">
                <label class="form-label">Quantity Requested (Quintals) *</label>
                <input type="number" id="offer-quantity" class="form-input">
            </div>
            <div class="form-group">
                <label class="form-label">Pickup Terms</label>
                <input type="text" id="offer-pickup" class="form-input" placeholder="e.g. Farmgate pickup within 48h">
            </div>
            <div class="form-group">
                <label class="form-label">Payment Terms</label>
                <input type="text" id="offer-payment" class="form-input" placeholder="e.g. Escrow + Bank Transfer">
            </div>
            <input type="hidden" id="offer-lot-id">
            <button class="btn btn-primary btn-full" onclick="submitOffer()">📩 Send Offer</button>
        </div>
    </div>

    <div class="toast-container" id="toast-container"></div>

    <script>
    const API = '<?= APP_BASE_URL ?>/api';
    let cropsCache = [];

    // Toast
    function showToast(msg, icon='✅') {
        const c = document.getElementById('toast-container');
        const t = document.createElement('div');
        t.className = 'toast';
        t.innerHTML = `<span>${icon}</span> <span>${msg}</span>`;
        c.appendChild(t);
        setTimeout(() => { t.style.opacity='0'; setTimeout(()=>t.remove(),300); }, 3500);
    }

    function closeModal(id) { document.getElementById(id).classList.remove('active'); }

    // Tab switch
    function showTab(tabId) {
        document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.getElementById('tab-' + tabId).classList.add('active');
        event.target.classList.add('active');
    }

    // Fetch helper
    async function api(url, options = {}) {
        const resp = await fetch(url, { headers: {'X-Requested-With': 'XMLHttpRequest'}, ...options });
        if (resp.status === 401) { location.href = '<?= APP_BASE_URL ?>/auth/login.php'; return null; }
        return resp.json();
    }

    // Load data
    async function loadAll() {
        loadStats();
        loadCrops();
        loadBrowseLots();
        loadMyRequirements();
        loadMyOffers();
        loadMyOrders();
    }

    async function loadStats() {
        const data = await api(API + '/dashboard.php');
        if (!data) return;
        document.getElementById('stat-requirements').textContent = data.requirement_count || 0;
        document.getElementById('stat-offers').textContent = data.active_offers || 0;
        document.getElementById('stat-orders').textContent = data.active_orders || 0;
        document.getElementById('stat-spent').textContent = '₹ ' + (data.total_spent || 0).toLocaleString('en-IN');
    }

    async function loadCrops() {
        const data = await api(API + '/crops.php?action=list');
        if (!data) return;
        cropsCache = data.crops || [];
        const sel = document.getElementById('req-crop');
        sel.innerHTML = cropsCache.map(c => `<option value="${c.id}">${c.icon} ${c.name_en}</option>`).join('');
    }

    async function loadBrowseLots() {
        const data = await api(API + '/lots.php?action=list&mode=marketplace');
        const container = document.getElementById('browse-lots-list');
        const lots = data?.lots || [];
        if (lots.length === 0) {
            container.innerHTML = '<div class="empty-state"><div class="empty-icon">🌾</div>No farmer lots available yet.</div>';
            return;
        }
        container.innerHTML = lots.map(l => `
            <div class="item-card">
                <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                    <div>
                        <div style="font-weight:800; font-size:18px;">${l.crop_icon} ${l.crop_name}</div>
                        <div style="font-size:13px; color:var(--text-muted);">Farmer: ${l.farmer_name} ${l.farmer_verified ? '⭐' : ''} | ${l.lot_code}</div>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:22px; font-weight:800; color:var(--primary-dark);">₹ ${parseFloat(l.expected_price).toLocaleString('en-IN')}</div>
                        <div style="font-size:12px; color:var(--text-muted);">per Quintal</div>
                    </div>
                </div>
                <div style="margin:8px 0; font-size:14px;">
                    <strong>Qty:</strong> ${l.quantity} ${l.unit} | <strong>Grade:</strong> ${l.grade_name || 'N/A'} | 📍 ${l.pickup_location_text || 'N/A'}
                </div>
                <button class="btn btn-primary btn-sm" onclick="openOfferModal(${l.id}, '${l.crop_name}', ${l.quantity}, ${l.expected_price})">📩 Make Offer</button>
            </div>
        `).join('');
    }

    async function loadMyRequirements() {
        const data = await api(API + '/buyer_requirements.php?action=list&mode=my');
        const container = document.getElementById('my-requirements-list');
        const reqs = data?.requirements || [];
        if (reqs.length === 0) {
            container.innerHTML = '<div class="empty-state"><div class="empty-icon">📌</div>No requirements posted yet. Go to "Post Requirement" tab.</div>';
            return;
        }
        container.innerHTML = reqs.map(r => `
            <div class="item-card">
                <div style="font-weight:800;">${r.icon} ${r.crop_name} — ${r.requirement_code}</div>
                <div>Qty: ${r.quantity_needed} ${r.unit} | Grade: ${r.grade_required || 'Any'}</div>
                <div style="font-weight:700; color:var(--accent-dark);">₹${r.min_price || '—'} - ₹${r.max_price || '—'} / Quintal</div>
                <span class="badge ${r.status === 'open' ? 'badge-available' : 'badge-pending'}">${r.status.toUpperCase()}</span>
            </div>
        `).join('');
    }

    async function loadMyOffers() {
        const data = await api(API + '/offers.php?action=list&mode=my_offers');
        const container = document.getElementById('my-offers-list');
        const offers = data?.offers || [];
        if (offers.length === 0) {
            container.innerHTML = '<div class="empty-state"><div class="empty-icon">📩</div>No offers sent yet. Browse farmer lots to make offers.</div>';
            return;
        }
        container.innerHTML = offers.map(o => `
            <div class="item-card">
                <div style="display:flex; justify-content:space-between;">
                    <div>
                        <div style="font-weight:800;">${o.crop_icon} ${o.crop_name} — ${o.offer_code}</div>
                        <div style="font-size:13px;">Farmer: ${o.farmer_name} | Lot: ${o.lot_code}</div>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:20px; font-weight:800; color:var(--primary-dark);">₹${parseFloat(o.offered_price).toLocaleString('en-IN')}/Q</div>
                        <span class="badge ${o.status === 'accepted' ? 'badge-paid' : o.status === 'active' ? 'badge-available' : 'badge-pending'}">${o.status.toUpperCase()}</span>
                    </div>
                </div>
            </div>
        `).join('');
    }

    async function loadMyOrders() {
        const data = await api(API + '/orders.php?action=list');
        const container = document.getElementById('my-orders-list');
        const orders = data?.orders || [];
        if (orders.length === 0) {
            container.innerHTML = '<div class="empty-state"><div class="empty-icon">📦</div>No orders yet. Accept offers from farmers to create orders.</div>';
            return;
        }
        container.innerHTML = orders.map(o => `
            <div class="item-card">
                <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
                    <div>
                        <span style="font-size:12px; color:var(--text-muted);">ORDER: ${o.order_code}</span>
                        <div style="font-weight:800; font-size:18px;">${o.crop_icon} ${o.crop_name}</div>
                    </div>
                    <span class="badge ${o.payment_status === 'paid_out' ? 'badge-paid' : 'badge-pending'}">${o.payment_status.replace(/_/g,' ').toUpperCase()}</span>
                </div>
                <div>Farmer: ${o.farmer_name} | Qty: ${o.quantity} ${o.unit} @ ₹${parseFloat(o.agreed_price).toLocaleString('en-IN')}/Q</div>
                <div style="font-weight:800; color:var(--primary-dark); font-size:18px; margin-top:4px;">Total: ₹${parseFloat(o.total_amount).toLocaleString('en-IN')}</div>
            </div>
        `).join('');
    }

    // Offer modal
    function openOfferModal(lotId, cropName, qty, askingPrice) {
        document.getElementById('offer-lot-id').value = lotId;
        document.getElementById('offer-lot-info').innerHTML = `<strong>${cropName}</strong> — ${qty} Quintals | Asking: ₹${askingPrice}/Q`;
        document.getElementById('offer-price').value = askingPrice;
        document.getElementById('offer-quantity').value = qty;
        document.getElementById('modal-offer').classList.add('active');
    }

    async function submitOffer() {
        const form = new FormData();
        form.append('action', 'create');
        form.append('lot_id', document.getElementById('offer-lot-id').value);
        form.append('offered_price', document.getElementById('offer-price').value);
        form.append('quantity_requested', document.getElementById('offer-quantity').value);
        form.append('pickup_terms', document.getElementById('offer-pickup').value);
        form.append('payment_terms', document.getElementById('offer-payment').value);

        const data = await api(API + '/offers.php', { method: 'POST', body: form });
        closeModal('modal-offer');
        if (data?.success) {
            showToast('Offer sent successfully! Code: ' + data.offer_code, '📩');
            loadAll();
        } else {
            showToast(data?.error || 'Failed to send offer', '⚠️');
        }
    }

    // Post requirement form
    document.getElementById('post-req-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const form = new FormData();
        form.append('action', 'create');
        form.append('crop_id', document.getElementById('req-crop').value);
        form.append('quantity_needed', document.getElementById('req-quantity').value);
        form.append('unit', document.getElementById('req-unit').value);
        form.append('min_price', document.getElementById('req-min-price').value);
        form.append('max_price', document.getElementById('req-max-price').value);
        form.append('grade_required', document.getElementById('req-grade').value);
        form.append('delivery_location', document.getElementById('req-delivery').value);
        form.append('description', document.getElementById('req-description').value);

        const data = await api(API + '/buyer_requirements.php', { method: 'POST', body: form });
        if (data?.success) {
            showToast('Requirement posted! Code: ' + data.requirement_code, '📌');
            e.target.reset();
            loadAll();
        } else {
            showToast(data?.error || 'Failed to post requirement', '⚠️');
        }
    });

    // Init
    loadAll();
    </script>
</body>
</html>
