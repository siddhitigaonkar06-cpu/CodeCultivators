// KisanSetu Mock Database & Initial State Data
const kisansetuData = {
  // Master Crops Catalog
  crops: [
    {
      id: "wheat",
      name: "Wheat (गेहूं / 🌾)",
      icon: "🌾",
      category: "Cereals",
      avgMandiPrice: 2450,
      priceUnit: "₹ / Quintal",
      change24h: 3.8,
      moistureMax: "12%",
      grades: {
        A: "Sharbati / Clean Bright Grain (<10% moisture, 0% foreign matter)",
        B: "Standard Commercial Grain (10-12% moisture, <1% foreign matter)",
        C: "Fair Average Quality (FAQ) (>12% moisture, minor broken)"
      },
      specimenImage: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=400&q=80"
    },
    {
      id: "onion",
      name: "Onion (प्याज / 🧅)",
      icon: "🧅",
      category: "Vegetables",
      avgMandiPrice: 2200,
      priceUnit: "₹ / Quintal",
      change24h: -1.5,
      moistureMax: "8%",
      grades: {
        A: "Large Red Export Quality (55mm+ diameter, dry skin)",
        B: "Medium Domestic Quality (40-50mm diameter)",
        C: "Small / Mixed Size (30-40mm diameter)"
      },
      specimenImage: "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cf?auto=format&fit=crop&w=400&q=80"
    },
    {
      id: "soybean",
      name: "Soybean (सोयाबीन / 🫘)",
      icon: "🫘",
      category: "Oilseeds",
      avgMandiPrice: 4850,
      priceUnit: "₹ / Quintal",
      change24h: 5.2,
      moistureMax: "10%",
      grades: {
        A: "Yellow Seed Grade 1 (>38% Oil content)",
        B: "Yellow Seed Grade 2 (35-37% Oil content)",
        C: "Mixed Commercial Seed"
      },
      specimenImage: "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=400&q=80"
    },
    {
      id: "potato",
      name: "Potato (आलू / 🥔)",
      icon: "🥔",
      category: "Vegetables",
      avgMandiPrice: 1650,
      priceUnit: "₹ / Quintal",
      change24h: 0.8,
      moistureMax: "15%",
      grades: {
        A: "Kufri Jyoti / Chipsona Large (>50mm, firm skin)",
        B: "Table Quality Medium (35-45mm)",
        C: "Small Seed Size (<35mm)"
      },
      specimenImage: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=400&q=80"
    },
    {
      id: "cotton",
      name: "Cotton (کپاس / ☁️)",
      icon: "☁️",
      category: "Fiber",
      avgMandiPrice: 6900,
      priceUnit: "₹ / Quintal",
      change24h: 2.1,
      moistureMax: "8%",
      grades: {
        A: "Long Staple (>29mm, Extra White)",
        B: "Medium Staple (24-28mm)",
        C: "Short Staple"
      },
      specimenImage: "https://images.unsplash.com/photo-1606041008023-472dfb5e530f?auto=format&fit=crop&w=400&q=80"
    },
    {
      id: "tomato",
      name: "Tomato (टमाटर / 🍅)",
      icon: "🍅",
      category: "Vegetables",
      avgMandiPrice: 2800,
      priceUnit: "₹ / Quintal",
      change24h: 8.4,
      moistureMax: "90%",
      grades: {
        A: "Hybrid Red Firm (Uniform size, no cracks)",
        B: "Semi-Ripe Pink/Red",
        C: "Processing Grade (Soft/Mixed)"
      },
      specimenImage: "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=400&q=80"
    },
    {
      id: "paddy",
      name: "Paddy / Rice (धान / 🌾)",
      icon: "🌾",
      category: "Cereals",
      avgMandiPrice: 2350,
      priceUnit: "₹ / Quintal",
      change24h: 1.2,
      moistureMax: "14%",
      grades: {
        A: "Basmati 1121 Extra Long",
        B: "Pusa 44 / Parmal Grade 1",
        C: "Common Coarse Paddy"
      },
      specimenImage: "https://images.unsplash.com/photo-1536304929831-ee1ca9d44906?auto=format&fit=crop&w=400&q=80"
    },
    {
      id: "mustard",
      name: "Mustard (सरसों / 🌼)",
      icon: "🌼",
      category: "Oilseeds",
      avgMandiPrice: 5400,
      priceUnit: "₹ / Quintal",
      change24h: 4.6,
      moistureMax: "8%",
      grades: {
        A: "Bold Black Seed (>42% Oil)",
        B: "Standard Seed (38-41% Oil)",
        C: "Mixed FAQ Seed"
      },
      specimenImage: "https://images.unsplash.com/photo-1508747703725-719777637510?auto=format&fit=crop&w=400&q=80"
    }
  ],

  // Mandi Comparison & Price Trends
  mandis: [
    { name: "Azadpur Mandi (Delhi)", distanceKm: 24, wheat: 2480, onion: 2250, soybean: 4900, potato: 1700, cotton: 7000 },
    { name: "Vashi APMC (Mumbai)", distanceKm: 420, wheat: 2520, onion: 2380, soybean: 4950, potato: 1820, cotton: 7100 },
    { name: "Lasalgaon Mandi (Nashik)", distanceKm: 280, wheat: 2410, onion: 2100, soybean: 4800, potato: 1600, cotton: 6850 },
    { name: "Khanna Grain Market (Punjab)", distanceKm: 180, wheat: 2460, onion: 2280, soybean: 4820, potato: 1650, cotton: 6920 },
    { name: "Indore Mandi (Madhya Pradesh)", distanceKm: 310, wheat: 2440, onion: 2180, soybean: 4890, potato: 1620, cotton: 6980 }
  ],

  priceHistory: {
    wheat: [
      { date: "25 Aug", price: 2340 },
      { date: "26 Aug", price: 2360 },
      { date: "27 Aug", price: 2390 },
      { date: "28 Aug", price: 2410 },
      { date: "29 Aug", price: 2420 },
      { date: "30 Aug", price: 2435 },
      { date: "31 Aug", price: 2450 }
    ],
    onion: [
      { date: "25 Aug", price: 2320 },
      { date: "26 Aug", price: 2290 },
      { date: "27 Aug", price: 2260 },
      { date: "28 Aug", price: 2240 },
      { date: "29 Aug", price: 2210 },
      { date: "30 Aug", price: 2200 },
      { date: "31 Aug", price: 2200 }
    ],
    soybean: [
      { date: "25 Aug", price: 4610 },
      { date: "26 Aug", price: 4660 },
      { date: "27 Aug", price: 4720 },
      { date: "28 Aug", price: 4780 },
      { date: "29 Aug", price: 4810 },
      { date: "30 Aug", price: 4830 },
      { date: "31 Aug", price: 4850 }
    ]
  },

  // Active Farmer Listed Lots
  farmerLots: [
    {
      id: "LOT-9081",
      farmerName: "Rameshwar Singh (रमेश्‍वर सिंह)",
      farmerPhone: "+91 98765 43210",
      cropId: "wheat",
      cropName: "Wheat (गेहूं)",
      cropIcon: "🌾",
      quantity: 120,
      unit: "Quintal",
      grade: "Grade A",
      expectedPrice: 2480,
      mandiRefPrice: 2450,
      harvestDate: "2026-08-20",
      location: "Village Rampur, Dist. Karnal, Haryana (PIN: 132001)",
      status: "available",
      offersCount: 3,
      qualitySpecs: "Moisture 9.5%, Clean Sharbati variety, 0.2% foreign matter",
      imageUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=400&q=80",
      createdAt: "2026-08-29"
    },
    {
      id: "LOT-9082",
      farmerName: "Savitri Devi (सावित्री देवी)",
      farmerPhone: "+91 98123 45678",
      cropId: "onion",
      cropName: "Onion (प्याज)",
      cropIcon: "🧅",
      quantity: 85,
      unit: "Quintal",
      grade: "Grade A",
      expectedPrice: 2250,
      mandiRefPrice: 2200,
      harvestDate: "2026-08-25",
      location: "Lasalgaon Road, Dist. Nashik, Maharashtra (PIN: 422306)",
      status: "in_bidding",
      offersCount: 5,
      qualitySpecs: "Red Onion 55mm Export Quality, dry outer shell",
      imageUrl: "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cf?auto=format&fit=crop&w=400&q=80",
      createdAt: "2026-08-30"
    },
    {
      id: "LOT-9083",
      farmerName: "Gurpreet Singh (ਗੁਰਪ੍ਰੀਤ ਸਿੰਘ)",
      farmerPhone: "+91 94567 89012",
      cropId: "soybean",
      cropName: "Soybean (सोयाबीन)",
      cropIcon: "🫘",
      quantity: 210,
      unit: "Quintal",
      grade: "Grade B",
      expectedPrice: 4900,
      mandiRefPrice: 4850,
      harvestDate: "2026-08-22",
      location: "Khanna Farm Gate, Ludhiana, Punjab (PIN: 141401)",
      status: "available",
      offersCount: 2,
      qualitySpecs: "Yellow Soybean, 38.5% Oil content certified",
      imageUrl: "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=400&q=80",
      createdAt: "2026-08-28"
    }
  ],

  // Real Structured Offers from Buyers
  buyerOffers: [
    {
      id: "OFF-301",
      buyerName: "ITC Agri Business Division",
      firmName: "ITC Choupal Fresh Ltd.",
      verified: true,
      rating: "4.9 ⭐",
      lotId: "LOT-9081",
      cropName: "Wheat",
      offeredPrice: 2500,
      quantityRequested: 120,
      pickupTerms: "Direct Farmgate Pickup within 48 hours (Freight paid by buyer)",
      paymentTerms: "Instant Escrow release upon digital weight scale verification",
      validUntil: "2026-09-02",
      status: "active"
    },
    {
      id: "OFF-302",
      buyerName: "Reliance Retail Agri Sourcing",
      firmName: "JioKrishi Procurement",
      verified: true,
      rating: "4.8 ⭐",
      lotId: "LOT-9081",
      cropName: "Wheat",
      offeredPrice: 2470,
      quantityRequested: 100,
      pickupTerms: "Delivery at Nearest Karnal Warehouse Hub",
      paymentTerms: "Direct Bank Transfer within 24 Hours",
      validUntil: "2026-09-03",
      status: "active"
    },
    {
      id: "OFF-303",
      buyerName: "Mahanagar Traders Co.",
      firmName: "Mahanagar Spices & Grains",
      verified: false,
      rating: "4.2 ⭐",
      lotId: "LOT-9082",
      cropName: "Onion",
      offeredPrice: 2280,
      quantityRequested: 85,
      pickupTerms: "Farmgate Pickup",
      paymentTerms: "Escrow Deposit Ready",
      validUntil: "2026-09-01",
      status: "active"
    }
  ],

  // Buyer Posted Procurement Requirements
  buyerRequirements: [
    {
      id: "REQ-501",
      buyerName: "Cargill India Foods Ltd.",
      cropNeeded: "Soybean",
      cropIcon: "🫘",
      quantityNeeded: 500,
      unit: "Quintal",
      offeredPriceRange: "₹4,850 - ₹4,950 / Quintal",
      gradeRequired: "Grade A / B (>38% Oil)",
      deliveryLocation: "Indore Processing Depot",
      verified: true
    },
    {
      id: "REQ-502",
      buyerName: "Mother Dairy Produce Ltd.",
      cropNeeded: "Tomato",
      cropIcon: "🍅",
      quantityNeeded: 150,
      unit: "Quintal",
      offeredPriceRange: "₹2,800 - ₹2,900 / Quintal",
      gradeRequired: "Grade A Hybrid Red",
      deliveryLocation: "Azadpur Mandi Hub",
      verified: true
    }
  ],

  // Logistics & Warehouses
  warehouses: [
    {
      id: "WH-101",
      name: "Central Warehouse Corporation (CWC) Karnal",
      type: "Scientific Grain Silo & Dry Storage",
      distanceKm: 8.5,
      totalCapacity: "15,000 Quintals",
      availableCapacity: "4,200 Quintals",
      dailyRate: "₹ 1.80 / Quintal / Day",
      features: "Fumigated, Temperature Monitored, NABARD Subsidy Eligible",
      phone: "+91 184 2256789"
    },
    {
      id: "WH-102",
      name: "Kisan Krishi Cold Storage & Ripening Centre",
      type: "Cold Storage (-2°C to 8°C)",
      distanceKm: 14.2,
      totalCapacity: "8,000 Quintals",
      availableCapacity: "1,850 Quintals",
      dailyRate: "₹ 3.50 / Quintal / Day",
      features: "Humidity Control for Onions/Potatoes, 24x7 Power Backup",
      phone: "+91 94160 11223"
    }
  ],

  transporters: [
    {
      id: "TR-201",
      providerName: "KisanSetu Verified Express Fleet",
      vehicleType: "Tata Ace / Mini Truck (1.5 Ton Capacity)",
      ratePerKm: "₹ 18 / km",
      baseFare: "₹ 350",
      contact: "+91 98111 22334",
      rating: "4.9 ⭐"
    },
    {
      id: "TR-202",
      providerName: "Haryana Roadways Cargo Transporters",
      vehicleType: "14-ft Eicher Truck (4 Ton Capacity)",
      ratePerKm: "₹ 32 / km",
      baseFare: "₹ 750",
      contact: "+91 94165 99887",
      rating: "4.7 ⭐"
    }
  ],

  // Payments & Transactions
  transactions: [
    {
      id: "TXN-88201",
      orderId: "ORD-9912",
      cropName: "Paddy / Rice (धान)",
      quantity: "150 Quintals",
      pricePerQuintal: 2350,
      totalAmount: 352500,
      escrowFee: 1762,
      netPayout: 350738,
      buyerName: "ITC Agri Business Division",
      paymentStatus: "Paid Out",
      statusBadge: "paid",
      date: "2026-08-27",
      bankUpi: "rameshwar@sbi",
      timeline: [
        { step: "Offer Accepted", date: "2026-08-25 10:30 AM", status: "complete" },
        { step: "Lot Picked Up", date: "2026-08-26 02:15 PM", status: "complete" },
        { step: "Quality Inspection Passed", date: "2026-08-26 05:45 PM", status: "complete" },
        { step: "Funds Transferred to Bank", date: "2026-08-27 11:00 AM", status: "complete" }
      ]
    },
    {
      id: "TXN-88202",
      orderId: "ORD-9915",
      cropName: "Wheat (गेहूं)",
      quantity: "120 Quintals",
      pricePerQuintal: 2500,
      totalAmount: 300000,
      escrowFee: 1500,
      netPayout: 298500,
      buyerName: "ITC Agri Business Division",
      paymentStatus: "Escrow Deposit Confirmed",
      statusBadge: "pending",
      date: "2026-08-30",
      bankUpi: "rameshwar@sbi",
      timeline: [
        { step: "Offer Accepted", date: "2026-08-30 09:15 AM", status: "complete" },
        { step: "Pickup Scheduled", date: "2026-08-31 10:00 AM", status: "current" },
        { step: "Quality Verification", date: "Pending", status: "upcoming" },
        { step: "Bank Release", date: "Pending", status: "upcoming" }
      ]
    }
  ],

  // FPO Hub Data
  fpo: {
    name: "Samriddhi Farmer Producer Co. Ltd. (समृद्धि एफपीओ)",
    fpoId: "FPO-HR-2024-009",
    regNo: "U01409HR2024PTC11899",
    membersCount: 185,
    villageCount: 12,
    totalAreaAcres: 640,
    collectiveProduce: [
      { crop: "Wheat", totalQty: "4,500 Quintals", availableQty: "1,200 Quintals", icon: "🌾" },
      { crop: "Soybean", totalQty: "2,200 Quintals", availableQty: "850 Quintals", icon: "🫘" },
      { crop: "Mustard", totalQty: "1,800 Quintals", availableQty: "600 Quintals", icon: "🌼" }
    ],
    bulkBuyerTenders: [
      {
        id: "TND-701",
        buyerName: "Adani Wilmar Agri Procurement",
        cropRequired: "Mustard (सरसों)",
        quantityNeeded: "1,000 Quintals",
        targetPrice: "₹ 5,450 / Quintal",
        deadline: "2026-09-05",
        status: "Open for FPO Bidding"
      }
    ],
    memberRoster: [
      { name: "Rameshwar Singh", land: "4.5 Acres", crop: "Wheat & Paddy", role: "Director" },
      { name: "Savitri Devi", land: "3.0 Acres", crop: "Onion & Tomato", role: "Member" },
      { name: "Baldev Raj", land: "6.0 Acres", crop: "Mustard & Wheat", role: "Member" }
    ]
  },

  // Grievance / Disputes
  grievances: [
    {
      id: "TKT-4401",
      subject: "Quality deduction discrepancy by Buyer",
      buyerName: "Mahanagar Traders Co.",
      cropName: "Wheat",
      amountDisputed: "₹ 12,500",
      status: "under_review",
      statusLabel: "Under Review by KisanSetu Arbitrator",
      filedDate: "2026-08-28",
      updates: [
        "2026-08-28: Ticket submitted by Farmer Rameshwar Singh.",
        "2026-08-29: Quality inspection report uploaded for verification.",
        "2026-08-30: Buyer response requested within 24 hours."
      ]
    }
  ],

  // Notifications
  notifications: [
    {
      id: "NOTIF-1",
      title: "🎉 High Offer Received!",
      message: "ITC Agri Business offered ₹ 2,500/Quintal for your Wheat Lot LOT-9081 (Above Mandi rate).",
      time: "10 mins ago",
      unread: true
    },
    {
      id: "NOTIF-2",
      title: "📈 Mandi Price Surge",
      message: "Soybean prices in Azadpur Mandi increased by +5.2% today.",
      time: "2 hours ago",
      unread: true
    },
    {
      id: "NOTIF-3",
      title: "🚚 Pickup Scheduled",
      message: "Transport provider Verified Express Fleet confirmed pickup for Aug 31, 10:00 AM.",
      time: "5 hours ago",
      unread: false
    }
  ]
};
