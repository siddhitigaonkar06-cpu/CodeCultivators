// KisanSetu i18n - DB-Backed Translation Loader
// Fetches translations from api/translations.php and caches locally

let translationsCache = {};
let supportedLanguages = [];
let langLabelsNative = {};

// Load translations from server
async function loadTranslations(lang) {
    try {
        const resp = await fetch(API_BASE + '/translations.php?lang=' + lang);
        const data = await resp.json();

        translationsCache = data.translations || {};
        supportedLanguages = data.supported_languages || [];

        // Build native labels
        langLabelsNative = {};
        supportedLanguages.forEach(l => {
            langLabelsNative[l.code] = `${l.name_native} (${l.name_english}) ${l.flag_emoji}`;
        });

        // Cache in localStorage
        localStorage.setItem('kisansetu_translations_' + lang, JSON.stringify(translationsCache));
        localStorage.setItem('kisansetu_lang', lang);

        applyLanguage(lang);
        initLanguagePicker();
    } catch (e) {
        console.warn('Translation fetch failed, using cached or defaults:', e);
        // Try localStorage cache
        const cached = localStorage.getItem('kisansetu_translations_' + lang);
        if (cached) {
            translationsCache = JSON.parse(cached);
            applyLanguage(lang);
        }
    }
}

// Initialize language picker modal
function initLanguagePicker() {
    const grid = document.getElementById('lang-picker-grid');
    if (!grid) return;
    grid.innerHTML = '';

    const langs = supportedLanguages.length > 0 ? supportedLanguages : Object.keys(langLabelsNative).map(code => ({
        code, name_native: langLabelsNative[code] || code
    }));

    langs.forEach(lang => {
        const btn = document.createElement('button');
        btn.className = `btn btn-secondary ${lang.code === currentLanguage ? 'btn-primary' : ''}`;
        btn.style.justifyContent = 'flex-start';
        btn.innerHTML = `${lang.name_native} (${lang.name_english || ''}) ${lang.flag_emoji || '🇮🇳'}`;
        btn.onclick = () => setLanguage(lang.code);
        grid.appendChild(btn);
    });
}

// Set language
function setLanguage(lang) {
    currentLanguage = lang;
    loadTranslations(lang);
    closeModal('modal-language');
    showToast(`Language updated!`, '🌐');
}

// Apply translations to the DOM
function applyLanguage(lang) {
    const dict = translationsCache;
    if (!dict || Object.keys(dict).length === 0) return;

    // Update language button text
    const langNameEl = document.getElementById('current-lang-name');
    if (langNameEl) {
        const langInfo = supportedLanguages.find(l => l.code === lang);
        langNameEl.innerText = langInfo ? langInfo.name_native : lang;
    }

    // Map element IDs to translation keys
    const textBindings = {
        'txt-appName': 'appName',
        'txt-tagline': 'tagline',
        'txt-navHome': 'navDashboard',
        'txt-navMyCrops': 'navMyCrops',
        'txt-navSellCrop': 'navSellCrop',
        'txt-navMarketplace': 'navMarketplace',
        'txt-navPriceTrends': 'navPriceTrends',
        'txt-navLogistics': 'navLogistics',
        'txt-navQuality': 'navQuality',
        'txt-navPayments': 'navPayments',
        'txt-navFPO': 'navFPO',
        'txt-navGrievance': 'navGrievance',
        'txt-mobHome': 'navDashboard',
        'txt-mobSell': 'navSellCrop',
        'txt-mobMarket': 'navMarketplace',
        'txt-mobRates': 'navPriceTrends',
        'txt-sellCTA': 'sellCropCTA',
        'txt-sellSub': 'sellCropSub',
        'txt-todayMandi': 'todayMandiPrices',
        'txt-activeOffers': 'activeBuyerOffers',
        'txt-myCropsTitle': 'yourCropsSummary',
        'txt-marketTitle': 'navMarketplace',
        'txt-priceTrendsTitle': 'priceTrendTitle',
        'txt-logisticsTitle': 'logisticsTitle'
    };

    Object.keys(textBindings).forEach(id => {
        const el = document.getElementById(id);
        const key = textBindings[id];
        if (el && dict[key]) {
            el.innerText = dict[key];
        }
    });
}

// Helper: get translated text
function t(key, fallback) {
    return translationsCache[key] || fallback || key;
}
