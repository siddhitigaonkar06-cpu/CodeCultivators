// KisanSetu Application Engine - Fully Dynamic (API-backed)
let currentLanguage = localStorage.getItem('kisansetu_lang') || CURRENT_USER.preferred_language || 'en';
let currentWizardStep = 1;
let cropsData = [];
let selectedCropForWizard = null;
let selectedGradeForWizard = null;
let selectedGradeId = null;
let uploadedImageUrl = '';
let activeCounterOfferId = null;

// API Helper
async function api(endpoint, options = {}) {
    try {
        const resp = await fetch(API_BASE + endpoint, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            ...options
        });
        if (resp.status === 401) {
            location.href = location.pathname.replace(/\/[^\/]*$/, '') + '/auth/login.php';
            return null;
        }
        return await resp.json();
    } catch (e) {
        console.error('API Error:', e);
        return null;
    }
}

// Initialize Application on Page Load
document.addEventListener('DOMContentLoaded', () => {
    loadTranslations(currentLanguage);
    loadAllData();
});

// Toast System
function showToast(message, icon = '✅') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

// Modal
function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function openLanguageModal() {
    document.getElementById('modal-language').classList.add('active');
}

// Navigation Engine
function switchSection(secId) {
    document.querySelectorAll('.page-section').forEach(sec => sec.classList.remove('active'));
    const targetSec = document.getElementById(`sec-${secId}`);
    if (targetSec) targetSec.classList.add('active');

    document.querySelectorAll('.nav-item-btn, .mob-nav-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-sec') === secId);
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ============================
// DATA LOADING
// ============================

async function loadAllData() {
    const cropData = await api('/crops.php?action=list');
    if (cropData) {
        cropsData = cropData.crops || [];
        renderMandiTicker();
        initWizardCropGrid();
        populateTrendCropSelect();
    }

    loadDashboardStats();
    loadMyOffers();
    loadMyCrops();
    loadMarketplaceOffers();
    loadLogistics();
    loadTransactions();
    loadFPO();
    loadNotifications();
    loadGrievances();
    loadProfile();
    loadMandiMatrix();
}

// ============================
// 1. DASHBOARD STATS
// ============================

async function loadDashboardStats() {
    const data = await api('/dashboard.php');
    if (!data) return;

    document.getElementById('summary-crop-count').textContent = (data.crop_count || 0) + ' Crops';
    document.getElementById('summary-crop-details').textContent =
        data.crop_names?.length ? data.crop_names.join(', ') + ' ready for sale' : 'No crops listed yet';

    document.getElementById('summary-offers-count').textContent = (data.offer_count || 0) + ' Offers';
    const hb = data.highest_bid;
    document.getElementById('summary-offers-details').textContent =
        hb ? `Highest bid: ₹${parseFloat(hb.max_price).toLocaleString('en-IN')}/Q (${hb.buyer_name})` : 'No active offers';

    document.getElementById('summary-escrow-amount').textContent = '₹ ' + (data.pending_payout || 0).toLocaleString('en-IN');
    document.getElementById('summary-payout-details').textContent =
        data.pending_payout > 0 ? 'Escrow status: Pending Release' : 'No pending payouts';
}

// ============================
// 2. MANDI TICKER
// ============================

function renderMandiTicker() {
    const container = document.getElementById('mandi-ticker-container');
    if (cropsData.length === 0) {
        container.innerHTML = '<div class="empty-state" style="width:100%;">No price data available. Add crops from admin panel.</div>';
        return;
    }
    container.innerHTML = '';
    cropsData.forEach(c => {
        const item = document.createElement('div');
        item.className = 'ticker-item';
        item.onclick = () => {
            document.getElementById('trend-crop-select').value = c.id;
            switchSection('price-trends');
            updatePriceTrendChart();
        };
        const isUp = c.change_24h >= 0;
        item.innerHTML = `
            <div class="ticker-header">${c.icon} ${c.name_en}</div>
            <div class="ticker-price">₹ ${parseFloat(c.avg_mandi_price || 0).toLocaleString('en-IN')} / Q</div>
            <div class="ticker-change ${isUp ? 'change-up' : 'change-down'}">
                ${isUp ? '▲' : '▼'} ${Math.abs(c.change_24h || 0)}% today
            </div>
        `;
        container.appendChild(item);
    });
}

// ============================
// 3. MY OFFERS (Home Preview + Marketplace)
// ============================

async function loadMyOffers() {
    const data = await api('/offers.php?action=list&mode=for_farmer');
    const offers = data?.offers || [];

    // Home preview (top 2)
    const homeContainer = document.getElementById('home-buyer-offers-list');
    if (offers.length === 0) {
        homeContainer.innerHTML = '<div class="empty-state" style="grid-column:1/-1;">No buyer offers yet. List your crops to receive offers.</div>';
    } else {
        homeContainer.innerHTML = offers.slice(0, 2).map(off => `
            <div class="card" style="background:var(--surface-bg);">
                <div style="display:flex; justify-content:space-between; margin-bottom:6px;">
                    <span class="badge badge-verified">${off.buyer_name} ${off.buyer_verified ? '⭐ Verified' : ''}</span>
                    <span style="font-weight:800; color:var(--primary-dark);">₹ ${parseFloat(off.offered_price).toLocaleString('en-IN')} / Q</span>
                </div>
                <div style="font-weight:700; font-size:16px;">${off.crop_icon || '🌾'} ${off.crop_name} (${off.quantity} ${off.unit || 'Quintals'})</div>
                <p style="font-size:13px; color:var(--text-muted); margin:6px 0;">${off.pickup_terms || 'Terms not specified'}</p>
                <div style="display:flex; gap:8px; margin-top:10px;">
                    <button class="btn btn-primary btn-sm btn-full" onclick="acceptOffer(${off.id})">Accept Offer</button>
                    <button class="btn btn-secondary btn-sm" onclick="openCounterModal(${off.id})">Counter</button>
                </div>
            </div>
        `).join('');
    }
}

// ============================
// 4. MY CROPS
// ============================

async function loadMyCrops() {
    const data = await api('/lots.php?action=list&mode=my');
    const grid = document.getElementById('my-crops-grid');
    const lots = data?.lots || [];

    if (lots.length === 0) {
        grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><div style="font-size:48px; margin-bottom:12px;">🌾</div>No crops listed yet. Create your first sell lot!</div>';
        return;
    }

    grid.innerHTML = lots.map(lot => {
        const imgUrl = lot.image_url || lot.specimen_image || '';
        return `
        <div class="card">
            ${imgUrl ? `<div style="position:relative; margin-bottom:12px;">
                <img src="${imgUrl}" style="width:100%; height:140px; object-fit:cover; border-radius:var(--radius-sm);" alt="${lot.crop_name}">
                <span class="badge badge-available" style="position:absolute; top:8px; right:8px;">${(lot.status || '').toUpperCase()}</span>
            </div>` : ''}
            <div style="font-size:18px; font-weight:800;">${lot.crop_icon} ${lot.crop_name}</div>
            <div style="font-size:14px; font-weight:700; color:var(--primary-dark); margin:4px 0;">
                ${lot.quantity} ${lot.unit} | ${lot.grade_name || 'N/A'}
            </div>
            <div style="font-size:13px; color:var(--text-muted);">Listed Price: <strong>₹ ${parseFloat(lot.expected_price).toLocaleString('en-IN')} / Q</strong></div>
            <div style="font-size:12px; color:var(--text-muted); margin-bottom:12px;">📍 ${lot.pickup_location_text || 'Location not set'}</div>
            <button class="btn btn-secondary btn-sm btn-full" onclick="switchSection('marketplace')">View Bids (${lot.offers_count || 0})</button>
        </div>`;
    }).join('');
}

// ============================
// 5. SELL WIZARD
// ============================

function initWizardCropGrid() {
    const grid = document.getElementById('wizard-crop-grid');
    grid.innerHTML = '';
    cropsData.forEach((c, index) => {
        const card = document.createElement('div');
        card.className = `crop-card-option ${index === 0 ? 'selected' : ''}`;
        card.onclick = () => selectCropWizard(c, card);
        card.innerHTML = `
            <div class="crop-card-icon">${c.icon}</div>
            <div class="crop-card-name">${c.name_en}</div>
        `;
        grid.appendChild(card);
    });
    if (cropsData.length > 0) {
        selectedCropForWizard = cropsData[0];
        updateWizardGrades(cropsData[0]);
        updateWizardBenchmark(cropsData[0]);
    }
}

function selectCropWizard(cropObj, el) {
    selectedCropForWizard = cropObj;
    document.querySelectorAll('.crop-card-option').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    updateWizardBenchmark(cropObj);
    updateWizardGrades(cropObj);
}

function updateWizardBenchmark(crop) {
    const price = parseFloat(crop.avg_mandi_price || 0);
    document.getElementById('wiz-mandi-benchmark').innerText = `₹ ${price.toLocaleString('en-IN')} / Quintal (${crop.ref_mandi || 'Nearest Mandi'})`;
    document.getElementById('wiz-price').value = price > 0 ? Math.round(price + 30) : 0;
}

function updateWizardGrades(crop) {
    const grid = document.getElementById('wizard-grade-grid');
    const grades = crop.grades || [];
    if (grades.length === 0) {
        grid.innerHTML = '<p style="color:var(--text-muted);">No grades defined for this crop.</p>';
        selectedGradeForWizard = 'Grade A';
        selectedGradeId = null;
        return;
    }
    grid.innerHTML = grades.map((g, i) => `
        <div class="grade-card ${i === 0 ? 'selected' : ''}" onclick="selectGrade('${g.grade_label}', ${g.id}, this)">
            <div class="grade-title">${g.grade_name} ${i === 0 ? '⭐' : ''}</div>
            <div class="grade-desc">${g.description_en || g.grade_label}</div>
        </div>
    `).join('');
    selectedGradeForWizard = grades[0].grade_label;
    selectedGradeId = grades[0].id;
}

function adjustQty(amount) {
    const input = document.getElementById('wiz-qty');
    let val = parseInt(input.value) || 100;
    val = Math.max(10, val + amount);
    input.value = val;
}

function selectGrade(gradeName, gradeId, el) {
    selectedGradeForWizard = gradeName;
    selectedGradeId = gradeId;
    document.querySelectorAll('.grade-card').forEach(g => g.classList.remove('selected'));
    el.classList.add('selected');
}

async function handlePhotoUpload(input) {
    if (!input.files || !input.files[0]) return;
    const formData = new FormData();
    formData.append('image', input.files[0]);

    showToast('Uploading image...', '📸');
    const data = await api('/upload.php', { method: 'POST', body: formData });
    if (data?.success) {
        uploadedImageUrl = data.image_url;
        const img = document.getElementById('wiz-img-display');
        img.src = data.image_url;
        img.style.display = 'block';
        showToast('Image uploaded successfully!', '✅');
    } else {
        showToast(data?.error || 'Upload failed', '⚠️');
    }
}

function wizNextStep() {
    if (currentWizardStep < 7) {
        currentWizardStep++;
        renderWizardStep(currentWizardStep);
    } else {
        publishLot();
    }
}

function wizPrevStep() {
    if (currentWizardStep > 1) {
        currentWizardStep--;
        renderWizardStep(currentWizardStep);
    }
}

function renderWizardStep(step) {
    for (let i = 1; i <= 7; i++) {
        document.getElementById(`wizard-step-content-${i}`).style.display = i === step ? 'block' : 'none';
        const pill = document.getElementById(`pill-step-${i}`);
        pill.className = i < step ? 'wizard-step-pill complete' : i === step ? 'wizard-step-pill active' : 'wizard-step-pill';
    }

    document.getElementById('wiz-btn-prev').style.visibility = step === 1 ? 'hidden' : 'visible';
    document.getElementById('wiz-btn-next').innerText = step === 7 ? '🚀 Publish Lot to Buyers' : 'Next Step ➔';

    if (step === 7) {
        const qty = document.getElementById('wiz-qty').value;
        const unit = document.getElementById('wiz-unit').value;
        const price = document.getElementById('wiz-price').value;
        const loc = document.getElementById('wiz-location').value;

        document.getElementById('wiz-summary-box').innerHTML = `
            <div style="font-weight:800; font-size:18px; color:var(--primary-dark); margin-bottom:8px;">
                ${selectedCropForWizard?.icon || '🌾'} ${selectedCropForWizard?.name_en || 'Crop'}
            </div>
            <div><strong>Quantity:</strong> ${qty} ${unit}</div>
            <div><strong>Quality Grade:</strong> ${selectedGradeForWizard || 'N/A'}</div>
            <div><strong>Target Price:</strong> ₹ ${price} / Quintal</div>
            <div><strong>Pickup Location:</strong> ${loc || 'Not set'}</div>
        `;
    }
}

async function publishLot() {
    const form = new FormData();
    form.append('action', 'create');
    form.append('crop_id', selectedCropForWizard?.id || '');
    form.append('grade_id', selectedGradeId || '');
    form.append('quantity', document.getElementById('wiz-qty').value);
    form.append('unit', document.getElementById('wiz-unit').value);
    form.append('expected_price', document.getElementById('wiz-price').value);
    form.append('pickup_location', document.getElementById('wiz-location').value);
    form.append('contact_phone', document.getElementById('wiz-phone').value);
    if (uploadedImageUrl) form.append('image_url', uploadedImageUrl);

    const data = await api('/lots.php', { method: 'POST', body: form });
    if (data?.success) {
        currentWizardStep = 1;
        renderWizardStep(1);
        uploadedImageUrl = '';
        switchSection('my-crops');
        showToast('🎉 Success! Your crop lot has been published to verified buyers.', '🚀');
        loadMyCrops();
        loadDashboardStats();
    } else {
        showToast(data?.error || 'Failed to publish lot', '⚠️');
    }
}

// ============================
// 6. MARKETPLACE
// ============================

async function loadMarketplaceOffers() {
    const data = await api('/offers.php?action=list&mode=for_farmer');
    const grid = document.getElementById('marketplace-offers-grid');
    const offers = data?.offers || [];

    if (offers.length === 0) {
        grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><div style="font-size:48px; margin-bottom:12px;">🛍️</div>No buyer offers yet. List your crops to receive offers from verified buyers.</div>';
        return;
    }

    grid.innerHTML = offers.map(off => `
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
                <div>
                    <div style="font-weight:800; font-size:18px;">${off.buyer_name}</div>
                    <span class="badge badge-verified">${off.firm_name || ''} ${off.buyer_verified ? '⭐ Verified Trader' : ''}</span>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:22px; font-weight:800; color:var(--primary-dark);">₹ ${parseFloat(off.offered_price).toLocaleString('en-IN')}</div>
                    <div style="font-size:12px; color:var(--text-muted);">per Quintal</div>
                </div>
            </div>
            <div style="background:var(--surface-bg); padding:12px; border-radius:var(--radius-sm); margin-bottom:12px;">
                <div><strong>Crop:</strong> ${off.crop_icon || '🌾'} ${off.crop_name} (${off.quantity} ${off.unit || 'Quintals'})</div>
                <div style="font-size:13px; color:var(--text-muted); margin-top:4px;">🚚 <strong>Pickup:</strong> ${off.pickup_terms || 'Not specified'}</div>
                <div style="font-size:13px; color:var(--text-muted);">💳 <strong>Payment:</strong> ${off.payment_terms || 'Not specified'}</div>
            </div>
            <div style="display:flex; gap:10px;">
                <button class="btn btn-primary btn-full" onclick="acceptOffer(${off.id})">Accept Offer</button>
                <button class="btn btn-secondary" onclick="openCounterModal(${off.id})">Counter Offer</button>
            </div>
        </div>
    `).join('');
}

async function acceptOffer(offerId) {
    const form = new FormData();
    form.append('action', 'accept');
    form.append('offer_id', offerId);

    const data = await api('/offers.php', { method: 'POST', body: form });
    if (data?.success) {
        showToast(`Offer accepted! Order ${data.order_code} created. Escrow confirmed.`, '🎉');
        loadAllData();
    } else {
        showToast(data?.error || 'Failed to accept offer', '⚠️');
    }
}

function openCounterModal(offerId) {
    activeCounterOfferId = offerId;
    document.getElementById('counter-offer-id').value = offerId;
    document.getElementById('modal-counter').classList.add('active');
}

async function submitCounterOffer() {
    const price = document.getElementById('counter-price-input').value;
    const form = new FormData();
    form.append('action', 'counter');
    form.append('offer_id', document.getElementById('counter-offer-id').value);
    form.append('counter_price', price);

    const data = await api('/offers.php', { method: 'POST', body: form });
    closeModal('modal-counter');
    if (data?.success) {
        showToast(`Counter offer of ₹${price}/Q submitted to buyer!`, '💬');
    } else {
        showToast(data?.error || 'Failed to submit counter offer', '⚠️');
    }
}

// ============================
// 7. PRICE TRENDS & CHART
// ============================

function populateTrendCropSelect() {
    const sel = document.getElementById('trend-crop-select');
    sel.innerHTML = cropsData.map(c => `<option value="${c.id}">${c.icon} ${c.name_en}</option>`).join('');
    if (cropsData.length > 0) updatePriceTrendChart();
}

async function updatePriceTrendChart() {
    const cropId = document.getElementById('trend-crop-select').value;
    if (!cropId) return;

    const data = await api(`/crops.php?action=price_history&crop_id=${cropId}&days=7`);
    const history = data?.history || [];
    renderPriceTrendChart(history);

    // AI advice
    const crop = cropsData.find(c => c.id == cropId);
    const adviceEl = document.getElementById('ai-trend-advice');
    if (crop && crop.change_24h > 3) {
        adviceEl.innerHTML = `🟢 <strong>High Demand Alert</strong>: ${crop.name_en} prices increased by +${crop.change_24h}%. Recommended to list within 3 days.`;
    } else if (crop && crop.change_24h < -2) {
        adviceEl.innerHTML = `🔴 <strong>Price Drop</strong>: ${crop.name_en} prices declined by ${crop.change_24h}%. Consider holding stock if storage available.`;
    } else {
        adviceEl.innerHTML = `🟡 <strong>Stable Market</strong>: ${crop?.name_en || 'Crop'} prices are relatively stable. Good time for steady sales.`;
    }
}

function renderPriceTrendChart(history) {
    const canvas = document.getElementById('priceCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    canvas.width = canvas.parentElement.clientWidth || 500;
    canvas.height = 220;

    if (history.length === 0) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#64748b';
        ctx.font = '16px Outfit, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('No price history data available', canvas.width / 2, 110);
        return;
    }

    const prices = history.map(h => parseFloat(h.price));
    const labels = history.map(h => h.date_label);
    const minP = Math.min(...prices) - 50;
    const maxP = Math.max(...prices) + 50;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Grid
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    for (let i = 0; i < 4; i++) {
        const y = 30 + i * 45;
        ctx.beginPath(); ctx.moveTo(40, y); ctx.lineTo(canvas.width - 20, y); ctx.stroke();
    }

    // Points
    const paddingLeft = 50, paddingRight = 30;
    const plotWidth = canvas.width - paddingLeft - paddingRight;
    const points = prices.map((p, idx) => ({
        x: paddingLeft + (idx / Math.max(prices.length - 1, 1)) * plotWidth,
        y: 180 - ((p - minP) / (maxP - minP || 1)) * 140,
        price: p, label: labels[idx]
    }));

    // Gradient
    const grad = ctx.createLinearGradient(0, 30, 0, 180);
    grad.addColorStop(0, 'rgba(5, 150, 105, 0.3)');
    grad.addColorStop(1, 'rgba(5, 150, 105, 0)');
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    points.forEach(pt => ctx.lineTo(pt.x, pt.y));
    ctx.lineTo(points[points.length - 1].x, 180);
    ctx.lineTo(points[0].x, 180);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line
    ctx.beginPath();
    ctx.strokeStyle = '#059669';
    ctx.lineWidth = 3;
    ctx.moveTo(points[0].x, points[0].y);
    points.forEach(pt => ctx.lineTo(pt.x, pt.y));
    ctx.stroke();

    // Dots + labels
    points.forEach(pt => {
        ctx.beginPath(); ctx.arc(pt.x, pt.y, 5, 0, Math.PI * 2);
        ctx.fillStyle = '#047857'; ctx.fill();
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.stroke();
        ctx.fillStyle = '#0f172a'; ctx.font = 'bold 11px Outfit, sans-serif'; ctx.textAlign = 'center';
        ctx.fillText(`₹${pt.price}`, pt.x, pt.y - 10);
        ctx.fillText(pt.label, pt.x, 200);
    });
}

// ============================
// 8. MANDI MATRIX
// ============================

async function loadMandiMatrix() {
    const data = await api('/crops.php?action=mandi_matrix');
    if (!data) return;

    const mandis = data.mandis || [];
    const crops = data.crops || [];

    // Build header
    const thead = document.getElementById('mandi-matrix-head');
    thead.innerHTML = `<tr style="background:var(--surface-bg); border-bottom:2px solid var(--border);">
        <th style="padding:12px;">Mandi Name</th>
        ${crops.map(c => `<th style="padding:12px;">${c.icon} ${c.name_en} (₹/Q)</th>`).join('')}
    </tr>`;

    // Build body
    const tbody = document.getElementById('mandi-matrix-body');
    tbody.innerHTML = mandis.map(m => `
        <tr style="border-bottom:1px solid var(--border);">
            <td style="padding:12px; font-weight:700;">${m.name}</td>
            ${crops.map(c => `<td style="padding:12px; font-weight:800; color:var(--primary-dark);">
                ${m.prices[c.slug] ? '₹ ' + parseFloat(m.prices[c.slug]).toLocaleString('en-IN') : '—'}
            </td>`).join('')}
        </tr>
    `).join('');
}

// ============================
// 9. LOGISTICS
// ============================

async function loadLogistics() {
    const data = await api('/logistics.php?action=list');
    if (!data) return;

    const whList = document.getElementById('warehouses-list');
    const warehouses = data.warehouses || [];
    whList.innerHTML = warehouses.length === 0 ? '<div class="empty-state">No warehouses listed yet.</div>'
        : warehouses.map(w => `
        <div style="margin-bottom:12px; padding:12px; border:1px solid var(--border); border-radius:var(--radius-sm);">
            <div style="font-weight:800;">${w.name}</div>
            <div style="font-size:13px; color:var(--text-muted);">${w.warehouse_type} | ${w.district}, ${w.state}</div>
            <div style="font-size:13px; font-weight:700; color:var(--primary-dark); margin:4px 0;">Available: ${w.available_capacity_quintals || '—'} Q (₹${w.daily_rate_per_quintal || '—'}/Q/Day)</div>
            <button class="btn btn-secondary btn-sm" onclick="bookStorage(${w.id})">Book Storage</button>
        </div>
    `).join('');

    const trList = document.getElementById('transporters-list');
    const transporters = data.transporters || [];
    trList.innerHTML = transporters.length === 0 ? '<div class="empty-state">No transporters listed yet.</div>'
        : transporters.map(t => `
        <div style="margin-bottom:12px; padding:12px; border:1px solid var(--border); border-radius:var(--radius-sm);">
            <div style="font-weight:800;">${t.provider_name}</div>
            <div style="font-size:13px; color:var(--text-muted);">${t.vehicle_type} | ⭐ ${t.rating}</div>
            <div style="font-size:13px; font-weight:700; color:var(--accent-dark); margin:4px 0;">Rate: ₹${t.rate_per_km}/km (Base: ₹${t.base_fare})</div>
            <button class="btn btn-secondary btn-sm" onclick="bookTransport(${t.id})">Schedule Pickup</button>
        </div>
    `).join('');
}

async function bookStorage(whId) {
    const form = new FormData();
    form.append('action', 'book_storage');
    form.append('warehouse_id', whId);
    form.append('quantity', 100);
    const data = await api('/logistics.php', { method: 'POST', body: form });
    showToast(data?.success ? `Storage booking ${data.booking_code} submitted!` : 'Booking failed', data?.success ? '🏬' : '⚠️');
}

async function bookTransport(trId) {
    const form = new FormData();
    form.append('action', 'book_transport');
    form.append('transporter_id', trId);
    form.append('pickup_address', 'Farm Gate');
    form.append('delivery_address', 'Nearest Mandi');
    const data = await api('/logistics.php', { method: 'POST', body: form });
    showToast(data?.success ? `Transport booking ${data.booking_code} initiated!` : 'Booking failed', data?.success ? '🚛' : '⚠️');
}

// ============================
// 10. QUALITY GRADE CALCULATOR
// ============================

function calculateGrade() {
    const m = parseFloat(document.getElementById('qual-moisture').value) || 0;
    const f = parseFloat(document.getElementById('qual-foreign').value) || 0;
    const res = document.getElementById('qual-calculated-result');

    if (m <= 10 && f <= 0.5) {
        res.innerText = "Grade A ⭐ (Super Clean)";
        res.className = "badge badge-verified";
    } else if (m <= 12 && f <= 1.5) {
        res.innerText = "Grade B (Standard)";
        res.className = "badge badge-pending";
    } else {
        res.innerText = "Grade C (Fair Average)";
        res.className = "badge";
    }
}

// ============================
// 11. TRANSACTIONS / PAYMENTS
// ============================

async function loadTransactions() {
    const data = await api('/orders.php?action=list');
    const container = document.getElementById('transactions-list');
    const orders = data?.orders || [];

    if (orders.length === 0) {
        container.innerHTML = '<div class="empty-state"><div style="font-size:48px; margin-bottom:12px;">💳</div>No transactions yet. Accept buyer offers to create orders.</div>';
        return;
    }

    container.innerHTML = orders.map(t => `
        <div class="card" style="margin-bottom:16px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                <div>
                    <span style="font-size:12px; color:var(--text-muted);">ORDER: ${t.order_code}</span>
                    <div style="font-weight:800; font-size:18px;">${t.crop_icon} ${t.crop_name}</div>
                </div>
                <span class="badge ${t.payment_status === 'paid_out' ? 'badge-paid' : 'badge-pending'}">${(t.payment_status || '').replace(/_/g,' ').toUpperCase()}</span>
            </div>
            <div style="display:flex; justify-content:space-between; margin-bottom:12px;">
                <div>Qty: <strong>${t.quantity} ${t.unit}</strong> @ ₹${parseFloat(t.agreed_price).toLocaleString('en-IN')}/Q</div>
                <div style="font-size:20px; font-weight:800; color:var(--primary-dark);">Net: ₹ ${parseFloat(t.net_farmer_payout).toLocaleString('en-IN')}</div>
            </div>
            ${t.timeline ? `<div style="margin-top:8px; padding-top:8px; border-top:1px solid var(--border);">
                ${t.timeline.map(s => `<div style="display:flex; align-items:center; gap:8px; padding:4px 0;">
                    <span style="font-size:12px;">${s.status === 'completed' ? '✅' : s.status === 'current' ? '🔄' : '⏳'}</span>
                    <span style="font-size:13px; font-weight:600;">${s.step_title}</span>
                    <span style="font-size:11px; color:var(--text-muted);">${s.completed_at || ''}</span>
                </div>`).join('')}
            </div>` : ''}
            <button class="btn btn-secondary btn-sm" style="margin-top:8px;" onclick="viewInvoice(${t.id})">📄 View Tax Receipt</button>
        </div>
    `).join('');
}

async function viewInvoice(orderId) {
    const data = await api(`/orders.php?action=get&id=${orderId}`);
    const t = data?.order;
    if (!t) return;

    document.getElementById('invoice-render-box').innerHTML = `
        <div class="invoice-header">
            <div>
                <div style="font-size:22px; font-weight:800; color:var(--primary-dark);">🌾 KisanSetu Tax Invoice</div>
                <div style="font-size:12px; color:var(--text-muted);">Escrow Transaction Receipt</div>
            </div>
            <div style="text-align:right;">
                <div style="font-weight:700;">${t.order_code}</div>
                <div style="font-size:12px; color:var(--text-muted);">${t.created_at}</div>
            </div>
        </div>
        <div><strong>Seller:</strong> ${t.farmer_name}</div>
        <div><strong>Buyer:</strong> ${t.buyer_name} (${t.buyer_firm || 'N/A'})</div>
        <hr style="margin:12px 0; border:none; border-top:1px solid var(--border);">
        <div style="display:flex; justify-content:space-between; margin-bottom:6px;">
            <span>Produce: ${t.crop_name} (${t.quantity} ${t.unit})</span>
            <span>₹ ${parseFloat(t.total_amount).toLocaleString('en-IN')}</span>
        </div>
        <div style="display:flex; justify-content:space-between; font-size:13px; color:var(--text-muted);">
            <span>KisanSetu Platform Fee (${t.platform_fee_percent}%)</span>
            <span>- ₹ ${parseFloat(t.platform_fee_amount).toLocaleString('en-IN')}</span>
        </div>
        <hr style="margin:12px 0; border:none; border-top:1px dashed var(--border);">
        <div style="display:flex; justify-content:space-between; font-size:18px; font-weight:800; color:var(--primary-dark);">
            <span>Net Bank Transfer Amount:</span>
            <span>₹ ${parseFloat(t.net_farmer_payout).toLocaleString('en-IN')}</span>
        </div>
        <div style="margin-top:16px; text-align:center; padding:10px; background:var(--surface-bg); border-radius:var(--radius-sm); font-size:12px;">
            🔒 Bank Account: ${t.farmer_upi || 'N/A'} | Escrow Secured by KisanSetu
        </div>
    `;
    document.getElementById('modal-invoice').classList.add('active');
}

// ============================
// 12. FPO
// ============================

async function loadFPO() {
    const data = await api('/fpo.php?action=my_fpo');
    const container = document.getElementById('fpo-content');

    if (!data?.fpo) {
        container.innerHTML = `
            <div class="card" style="text-align:center; padding:40px;">
                <div style="font-size:48px; margin-bottom:12px;">👥</div>
                <h3 style="font-weight:800;">You are not a member of any FPO</h3>
                <p style="color:var(--text-muted); margin-top:8px;">Contact your local Farmer Producer Organization to join.</p>
            </div>
        `;
        return;
    }

    const fpo = data.fpo;
    container.innerHTML = `
        <div class="card" style="background:linear-gradient(135deg, #0284c7, #0369a1); color:white; margin-bottom:20px;">
            <h2 style="font-size:24px; font-weight:800;">${fpo.name}</h2>
            <p style="opacity:0.9;">Reg: ${fpo.registration_number || 'N/A'} | ${fpo.members_count} Members | Your Role: ${fpo.member_role || 'Member'}</p>
        </div>
        <div class="grid-2" style="margin-bottom:20px;">
            <div class="card">
                <h3 style="font-weight:800; margin-bottom:12px;">📦 Collective Produce</h3>
                ${(fpo.collective_produce || []).map(p => `
                    <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid var(--border);">
                        <span>${p.icon} <strong>${p.crop_name}</strong></span>
                        <span>${p.available_quantity} / ${p.total_quantity} ${p.unit}</span>
                    </div>
                `).join('') || '<div class="empty-state">No produce data.</div>'}
            </div>
            <div class="card">
                <h3 style="font-weight:800; margin-bottom:12px;">🏬 Bulk Buyer Tenders</h3>
                ${(fpo.tenders || []).map(t => `
                    <div style="padding:10px; border:1px solid var(--border); border-radius:var(--radius-sm); margin-bottom:8px;">
                        <div style="font-weight:800;">${t.buyer_name}</div>
                        <div>${t.icon} ${t.crop_name} - ${t.quantity_needed} ${t.unit}</div>
                        <div style="font-weight:700; color:var(--primary-dark);">₹ ${parseFloat(t.target_price || 0).toLocaleString('en-IN')} / Q</div>
                        <button class="btn btn-primary btn-sm" style="margin-top:6px;" onclick="submitFpoBid(${t.id})">Submit FPO Bid</button>
                    </div>
                `).join('') || '<div class="empty-state">No open tenders.</div>'}
            </div>
        </div>
    `;
}

async function submitFpoBid(tenderId) {
    const form = new FormData();
    form.append('action', 'submit_bid');
    form.append('tender_id', tenderId);
    form.append('bid_price', 0);
    form.append('quantity_offered', 0);
    const data = await api('/fpo.php', { method: 'POST', body: form });
    showToast(data?.success ? 'FPO Bid submitted!' : (data?.error || 'Failed'), data?.success ? '👥' : '⚠️');
}

// ============================
// 13. NOTIFICATIONS
// ============================

async function loadNotifications() {
    const data = await api('/notifications.php?action=list');
    if (!data) return;

    // Badge
    document.getElementById('notif-count').textContent = data.unread_count || 0;
    if (data.unread_count == 0) document.getElementById('notif-count').style.display = 'none';
    else document.getElementById('notif-count').style.display = 'flex';

    // List
    const box = document.getElementById('notifications-container');
    const notifs = data.notifications || [];
    if (notifs.length === 0) {
        box.innerHTML = '<div class="empty-state">No notifications yet.</div>';
        return;
    }
    box.innerHTML = notifs.map(n => `
        <div style="padding:12px; border-bottom:1px solid var(--border); ${n.is_read ? '' : 'background:var(--primary-light);'}">
            <div style="font-weight:800; font-size:15px;">${n.icon || '🔔'} ${n.title}</div>
            <div style="font-size:14px; color:var(--text-main); margin:4px 0;">${n.message}</div>
            <div style="font-size:11px; color:var(--text-muted);">${n.created_at}</div>
        </div>
    `).join('');
}

async function markAllRead() {
    const form = new FormData();
    form.append('action', 'mark_read');
    await api('/notifications.php', { method: 'POST', body: form });
    loadNotifications();
    showToast('All notifications marked as read', '✅');
}

// ============================
// 14. GRIEVANCES
// ============================

async function loadGrievances() {
    const data = await api('/grievances.php?action=list');
    const list = document.getElementById('grievance-tickets-list');
    const grievances = data?.grievances || [];

    if (grievances.length === 0) {
        list.innerHTML = '<div class="empty-state">No complaint tickets filed.</div>';
        return;
    }
    list.innerHTML = grievances.map(g => `
        <div style="padding:12px; border:1px solid var(--border); border-radius:var(--radius-sm); margin-bottom:10px;">
            <div style="font-weight:800; color:var(--danger);">${g.ticket_code}: ${g.subject}</div>
            <div style="font-size:13px; color:var(--text-muted);">Category: ${g.category} | Amount: ₹${g.amount_disputed || 0}</div>
            <span class="badge badge-pending" style="margin-top:6px;">Status: ${(g.status || '').replace(/_/g, ' ').toUpperCase()}</span>
            ${(g.updates || []).map(u => `<div style="font-size:12px; color:var(--text-muted); margin-top:4px;">• ${u.update_text}</div>`).join('')}
        </div>
    `).join('');
}

// Grievance form
document.getElementById('grievance-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData();
    form.append('action', 'create');
    form.append('category', document.getElementById('grip-category').value);
    form.append('subject', document.getElementById('grip-subject').value);
    form.append('description', document.getElementById('grip-details').value);
    form.append('amount_disputed', document.getElementById('grip-amount').value);

    if (!document.getElementById('grip-details').value) {
        showToast('Please enter details before submitting', '⚠️');
        return;
    }

    const data = await api('/grievances.php', { method: 'POST', body: form });
    if (data?.success) {
        showToast(`Grievance ${data.ticket_code} filed. Arbitrator will contact within 24h.`, '🛡️');
        e.target.reset();
        loadGrievances();
    } else {
        showToast(data?.error || 'Failed to submit grievance', '⚠️');
    }
});

// ============================
// 15. PROFILE
// ============================

async function loadProfile() {
    const data = await api('/profile.php?action=get');
    if (!data?.profile) return;

    const p = data.profile;
    const addr = p.address;
    const bank = p.bank;
    const fpo = p.fpo_membership;

    document.getElementById('profile-name').textContent = p.full_name;
    document.getElementById('profile-location').textContent = addr ? `${addr.village || ''} ${addr.district}, ${addr.state}` : 'Location not set';

    const badges = [];
    if (p.aadhaar_verified) badges.push('Aadhaar');
    if (p.kcc_verified) badges.push('KCC');
    if (p.is_verified) badges.push('Phone');
    document.getElementById('profile-badge').textContent = badges.length ? '⭐ ' + badges.join(' & ') + ' Verified' : 'Not verified';

    document.getElementById('profile-details').innerHTML = `
        <div class="form-group">
            <label class="form-label">Phone Number</label>
            <input type="text" class="form-input" value="${p.phone}" readonly>
        </div>
        <div class="form-group">
            <label class="form-label">Bank UPI ID</label>
            <input type="text" class="form-input" value="${bank?.upi_id || 'Not set'}" readonly>
        </div>
        <div class="form-group">
            <label class="form-label">Bank Account</label>
            <input type="text" class="form-input" value="${bank ? bank.bank_name + ' - ' + bank.account_number : 'Not set'}" readonly>
        </div>
        ${p.total_land_acres ? `<div class="form-group">
            <label class="form-label">Total Land</label>
            <input type="text" class="form-input" value="${p.total_land_acres} Acres" readonly>
        </div>` : ''}
        ${fpo ? `<div class="form-group">
            <label class="form-label">FPO Membership</label>
            <input type="text" class="form-input" value="${fpo.name} - ${fpo.member_role}" readonly>
        </div>` : ''}
    `;
}
