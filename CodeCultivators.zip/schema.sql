-- ============================================================
-- KisanSetu - Full MySQL Database Schema
-- Fully dynamic, zero mockup data
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+05:30";

CREATE DATABASE IF NOT EXISTS `kisansetu_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `kisansetu_db`;

-- ============================================================
-- 1. USERS & AUTHENTICATION
-- ============================================================

CREATE TABLE `users` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `phone` VARCHAR(20) NOT NULL UNIQUE,
  `email` VARCHAR(150) DEFAULT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('farmer','buyer','merchant','admin') NOT NULL DEFAULT 'farmer',
  `full_name` VARCHAR(150) NOT NULL,
  `display_name` VARCHAR(100) DEFAULT NULL,
  `avatar_url` VARCHAR(500) DEFAULT NULL,
  `preferred_language` VARCHAR(10) NOT NULL DEFAULT 'en',
  `is_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `last_login_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_users_role` (`role`),
  INDEX `idx_users_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `user_sessions` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `session_token` VARCHAR(255) NOT NULL UNIQUE,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` TEXT DEFAULT NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_sessions_token` (`session_token`),
  INDEX `idx_sessions_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `user_profiles` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL UNIQUE,
  `aadhaar_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `kcc_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `pan_number` VARCHAR(20) DEFAULT NULL,
  `gst_number` VARCHAR(30) DEFAULT NULL,
  `firm_name` VARCHAR(200) DEFAULT NULL,
  `firm_type` ENUM('individual','proprietorship','partnership','company','cooperative','fpo') DEFAULT 'individual',
  `total_land_acres` DECIMAL(10,2) DEFAULT NULL,
  `primary_crops` TEXT DEFAULT NULL,
  `rating` DECIMAL(3,2) DEFAULT 0.00,
  `total_transactions` INT UNSIGNED DEFAULT 0,
  `bio` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `user_addresses` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `label` VARCHAR(50) NOT NULL DEFAULT 'primary',
  `address_line1` VARCHAR(255) NOT NULL,
  `address_line2` VARCHAR(255) DEFAULT NULL,
  `village` VARCHAR(100) DEFAULT NULL,
  `district` VARCHAR(100) NOT NULL,
  `state` VARCHAR(100) NOT NULL,
  `pincode` VARCHAR(10) NOT NULL,
  `latitude` DECIMAL(10,7) DEFAULT NULL,
  `longitude` DECIMAL(10,7) DEFAULT NULL,
  `is_default` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_address_user` (`user_id`),
  INDEX `idx_address_state` (`state`),
  INDEX `idx_address_district` (`district`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `user_bank_details` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `account_holder_name` VARCHAR(150) NOT NULL,
  `bank_name` VARCHAR(150) NOT NULL,
  `account_number` VARCHAR(30) NOT NULL,
  `ifsc_code` VARCHAR(15) NOT NULL,
  `upi_id` VARCHAR(100) DEFAULT NULL,
  `is_primary` TINYINT(1) NOT NULL DEFAULT 1,
  `verified` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_bank_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `user_verifications` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `verification_type` ENUM('phone','email','aadhaar','kcc','pan','gst','trade_license') NOT NULL,
  `verification_value` VARCHAR(255) NOT NULL,
  `document_url` VARCHAR(500) DEFAULT NULL,
  `status` ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  `verified_by` INT UNSIGNED DEFAULT NULL,
  `verified_at` DATETIME DEFAULT NULL,
  `rejection_reason` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_verification_user` (`user_id`),
  INDEX `idx_verification_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 2. CROPS & CATALOG
-- ============================================================

CREATE TABLE `crop_categories` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `name_hi` VARCHAR(100) DEFAULT NULL,
  `icon` VARCHAR(10) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `sort_order` INT UNSIGNED DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `crops` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `slug` VARCHAR(50) NOT NULL UNIQUE,
  `name_en` VARCHAR(100) NOT NULL,
  `name_hi` VARCHAR(100) DEFAULT NULL,
  `name_local` VARCHAR(100) DEFAULT NULL,
  `icon` VARCHAR(10) NOT NULL DEFAULT '🌾',
  `category_id` INT UNSIGNED NOT NULL,
  `msp_price` DECIMAL(12,2) DEFAULT NULL COMMENT 'Minimum Support Price set by govt',
  `default_price_unit` VARCHAR(50) NOT NULL DEFAULT '₹ / Quintal',
  `moisture_max_percent` DECIMAL(5,2) DEFAULT NULL,
  `specimen_image_url` VARCHAR(500) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT UNSIGNED DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `crop_categories`(`id`),
  INDEX `idx_crops_category` (`category_id`),
  INDEX `idx_crops_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `crop_grades` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `crop_id` INT UNSIGNED NOT NULL,
  `grade_name` VARCHAR(20) NOT NULL COMMENT 'Grade A, Grade B, Grade C',
  `grade_label` VARCHAR(100) NOT NULL,
  `grade_label_hi` VARCHAR(100) DEFAULT NULL,
  `description_en` TEXT DEFAULT NULL,
  `description_hi` TEXT DEFAULT NULL,
  `moisture_max` DECIMAL(5,2) DEFAULT NULL,
  `foreign_matter_max` DECIMAL(5,2) DEFAULT NULL,
  `price_premium_percent` DECIMAL(5,2) DEFAULT 0.00 COMMENT 'premium/discount vs base price',
  `sort_order` INT UNSIGNED DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`crop_id`) REFERENCES `crops`(`id`) ON DELETE CASCADE,
  INDEX `idx_grades_crop` (`crop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `crop_images` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `crop_id` INT UNSIGNED NOT NULL,
  `image_url` VARCHAR(500) NOT NULL,
  `caption` VARCHAR(255) DEFAULT NULL,
  `is_specimen` TINYINT(1) NOT NULL DEFAULT 0,
  `sort_order` INT UNSIGNED DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`crop_id`) REFERENCES `crops`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 3. MANDI / MARKET PRICES
-- ============================================================

CREATE TABLE `mandi_list` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) NOT NULL,
  `name_hi` VARCHAR(200) DEFAULT NULL,
  `state` VARCHAR(100) NOT NULL,
  `district` VARCHAR(100) NOT NULL,
  `latitude` DECIMAL(10,7) DEFAULT NULL,
  `longitude` DECIMAL(10,7) DEFAULT NULL,
  `apmc_code` VARCHAR(50) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_mandi_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `mandi_prices` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `mandi_id` INT UNSIGNED NOT NULL,
  `crop_id` INT UNSIGNED NOT NULL,
  `price_date` DATE NOT NULL,
  `min_price` DECIMAL(12,2) DEFAULT NULL,
  `max_price` DECIMAL(12,2) DEFAULT NULL,
  `modal_price` DECIMAL(12,2) NOT NULL COMMENT 'Most common trading price',
  `price_unit` VARCHAR(30) NOT NULL DEFAULT 'Quintal',
  `arrival_qty_tonnes` DECIMAL(12,2) DEFAULT NULL,
  `change_percent` DECIMAL(6,2) DEFAULT NULL,
  `source` VARCHAR(100) DEFAULT 'manual',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`mandi_id`) REFERENCES `mandi_list`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`crop_id`) REFERENCES `crops`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `uq_mandi_crop_date` (`mandi_id`, `crop_id`, `price_date`),
  INDEX `idx_mandi_prices_date` (`price_date`),
  INDEX `idx_mandi_prices_crop` (`crop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `mandi_price_history` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `mandi_id` INT UNSIGNED NOT NULL,
  `crop_id` INT UNSIGNED NOT NULL,
  `price_date` DATE NOT NULL,
  `modal_price` DECIMAL(12,2) NOT NULL,
  `price_unit` VARCHAR(30) NOT NULL DEFAULT 'Quintal',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`mandi_id`) REFERENCES `mandi_list`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`crop_id`) REFERENCES `crops`(`id`) ON DELETE CASCADE,
  INDEX `idx_history_mandi_crop` (`mandi_id`, `crop_id`),
  INDEX `idx_history_date` (`price_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 4. FARMER LOTS (Sell Listings)
-- ============================================================

CREATE TABLE `farmer_lots` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `lot_code` VARCHAR(20) NOT NULL UNIQUE,
  `farmer_id` INT UNSIGNED NOT NULL,
  `crop_id` INT UNSIGNED NOT NULL,
  `grade_id` INT UNSIGNED DEFAULT NULL,
  `quantity` DECIMAL(12,2) NOT NULL,
  `unit` ENUM('Quintal','Kg','Ton','Bag') NOT NULL DEFAULT 'Quintal',
  `expected_price` DECIMAL(12,2) NOT NULL,
  `mandi_ref_price` DECIMAL(12,2) DEFAULT NULL,
  `harvest_date` DATE DEFAULT NULL,
  `expiry_date` DATE DEFAULT NULL COMMENT 'Listing validity',
  `description` TEXT DEFAULT NULL,
  `quality_specs` TEXT DEFAULT NULL,
  `moisture_percent` DECIMAL(5,2) DEFAULT NULL,
  `foreign_matter_percent` DECIMAL(5,2) DEFAULT NULL,
  `pickup_address_id` INT UNSIGNED DEFAULT NULL,
  `pickup_location_text` VARCHAR(500) DEFAULT NULL,
  `pickup_latitude` DECIMAL(10,7) DEFAULT NULL,
  `pickup_longitude` DECIMAL(10,7) DEFAULT NULL,
  `contact_phone` VARCHAR(20) DEFAULT NULL,
  `status` ENUM('draft','available','in_bidding','sold','expired','withdrawn') NOT NULL DEFAULT 'available',
  `offers_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `views_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `featured` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`farmer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`crop_id`) REFERENCES `crops`(`id`),
  FOREIGN KEY (`grade_id`) REFERENCES `crop_grades`(`id`),
  FOREIGN KEY (`pickup_address_id`) REFERENCES `user_addresses`(`id`),
  INDEX `idx_lots_farmer` (`farmer_id`),
  INDEX `idx_lots_crop` (`crop_id`),
  INDEX `idx_lots_status` (`status`),
  INDEX `idx_lots_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `lot_images` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `lot_id` INT UNSIGNED NOT NULL,
  `image_url` VARCHAR(500) NOT NULL,
  `caption` VARCHAR(255) DEFAULT NULL,
  `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
  `sort_order` INT UNSIGNED DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`lot_id`) REFERENCES `farmer_lots`(`id`) ON DELETE CASCADE,
  INDEX `idx_lot_images_lot` (`lot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 5. BUYER OFFERS & REQUIREMENTS
-- ============================================================

CREATE TABLE `buyer_offers` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `offer_code` VARCHAR(20) NOT NULL UNIQUE,
  `buyer_id` INT UNSIGNED NOT NULL,
  `lot_id` INT UNSIGNED NOT NULL,
  `offered_price` DECIMAL(12,2) NOT NULL,
  `quantity_requested` DECIMAL(12,2) NOT NULL,
  `pickup_terms` TEXT DEFAULT NULL,
  `payment_terms` TEXT DEFAULT NULL,
  `valid_until` DATE DEFAULT NULL,
  `message` TEXT DEFAULT NULL,
  `status` ENUM('active','accepted','rejected','countered','expired','withdrawn') NOT NULL DEFAULT 'active',
  `accepted_at` DATETIME DEFAULT NULL,
  `rejected_at` DATETIME DEFAULT NULL,
  `rejection_reason` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`buyer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`lot_id`) REFERENCES `farmer_lots`(`id`) ON DELETE CASCADE,
  INDEX `idx_offers_buyer` (`buyer_id`),
  INDEX `idx_offers_lot` (`lot_id`),
  INDEX `idx_offers_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `counter_offers` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `offer_id` INT UNSIGNED NOT NULL,
  `from_user_id` INT UNSIGNED NOT NULL,
  `to_user_id` INT UNSIGNED NOT NULL,
  `counter_price` DECIMAL(12,2) NOT NULL,
  `counter_quantity` DECIMAL(12,2) DEFAULT NULL,
  `message` TEXT DEFAULT NULL,
  `status` ENUM('pending','accepted','rejected','expired') NOT NULL DEFAULT 'pending',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`offer_id`) REFERENCES `buyer_offers`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`from_user_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`to_user_id`) REFERENCES `users`(`id`),
  INDEX `idx_counter_offer` (`offer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `buyer_requirements` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `requirement_code` VARCHAR(20) NOT NULL UNIQUE,
  `buyer_id` INT UNSIGNED NOT NULL,
  `crop_id` INT UNSIGNED NOT NULL,
  `quantity_needed` DECIMAL(12,2) NOT NULL,
  `unit` ENUM('Quintal','Kg','Ton','Bag') NOT NULL DEFAULT 'Quintal',
  `min_price` DECIMAL(12,2) DEFAULT NULL,
  `max_price` DECIMAL(12,2) DEFAULT NULL,
  `grade_required` VARCHAR(100) DEFAULT NULL,
  `delivery_location` VARCHAR(500) DEFAULT NULL,
  `delivery_deadline` DATE DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `status` ENUM('open','partially_fulfilled','fulfilled','closed','expired') NOT NULL DEFAULT 'open',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`buyer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`crop_id`) REFERENCES `crops`(`id`),
  INDEX `idx_req_buyer` (`buyer_id`),
  INDEX `idx_req_crop` (`crop_id`),
  INDEX `idx_req_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 6. ORDERS & TRANSACTIONS
-- ============================================================

CREATE TABLE `orders` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `order_code` VARCHAR(20) NOT NULL UNIQUE,
  `lot_id` INT UNSIGNED NOT NULL,
  `offer_id` INT UNSIGNED DEFAULT NULL,
  `farmer_id` INT UNSIGNED NOT NULL,
  `buyer_id` INT UNSIGNED NOT NULL,
  `crop_id` INT UNSIGNED NOT NULL,
  `quantity` DECIMAL(12,2) NOT NULL,
  `unit` ENUM('Quintal','Kg','Ton','Bag') NOT NULL DEFAULT 'Quintal',
  `agreed_price` DECIMAL(12,2) NOT NULL,
  `total_amount` DECIMAL(14,2) NOT NULL,
  `platform_fee_percent` DECIMAL(5,2) NOT NULL DEFAULT 0.50,
  `platform_fee_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `net_farmer_payout` DECIMAL(14,2) NOT NULL,
  `pickup_location` VARCHAR(500) DEFAULT NULL,
  `delivery_location` VARCHAR(500) DEFAULT NULL,
  `pickup_date` DATE DEFAULT NULL,
  `delivery_date` DATE DEFAULT NULL,
  `quality_report` TEXT DEFAULT NULL,
  `status` ENUM('pending','confirmed','pickup_scheduled','picked_up','in_transit','delivered','quality_check','payment_processing','completed','cancelled','disputed') NOT NULL DEFAULT 'pending',
  `payment_status` ENUM('awaiting_escrow','escrow_deposited','escrow_released','paid_out','refunded','on_hold') NOT NULL DEFAULT 'awaiting_escrow',
  `cancellation_reason` TEXT DEFAULT NULL,
  `cancelled_by` INT UNSIGNED DEFAULT NULL,
  `completed_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`lot_id`) REFERENCES `farmer_lots`(`id`),
  FOREIGN KEY (`offer_id`) REFERENCES `buyer_offers`(`id`),
  FOREIGN KEY (`farmer_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`buyer_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`crop_id`) REFERENCES `crops`(`id`),
  INDEX `idx_orders_farmer` (`farmer_id`),
  INDEX `idx_orders_buyer` (`buyer_id`),
  INDEX `idx_orders_status` (`status`),
  INDEX `idx_orders_payment` (`payment_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `order_timeline` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT UNSIGNED NOT NULL,
  `step_title` VARCHAR(200) NOT NULL,
  `step_description` TEXT DEFAULT NULL,
  `status` ENUM('completed','current','upcoming') NOT NULL DEFAULT 'upcoming',
  `completed_at` DATETIME DEFAULT NULL,
  `created_by` INT UNSIGNED DEFAULT NULL,
  `sort_order` INT UNSIGNED DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  INDEX `idx_timeline_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `transactions` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `transaction_code` VARCHAR(30) NOT NULL UNIQUE,
  `order_id` INT UNSIGNED NOT NULL,
  `payer_id` INT UNSIGNED NOT NULL,
  `payee_id` INT UNSIGNED NOT NULL,
  `amount` DECIMAL(14,2) NOT NULL,
  `transaction_type` ENUM('escrow_deposit','escrow_release','farmer_payout','platform_fee','refund','penalty') NOT NULL,
  `payment_method` ENUM('upi','bank_transfer','neft','rtgs','wallet','cash') DEFAULT 'bank_transfer',
  `payment_reference` VARCHAR(100) DEFAULT NULL,
  `bank_upi_id` VARCHAR(100) DEFAULT NULL,
  `status` ENUM('initiated','processing','completed','failed','reversed') NOT NULL DEFAULT 'initiated',
  `processed_at` DATETIME DEFAULT NULL,
  `failure_reason` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`),
  FOREIGN KEY (`payer_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`payee_id`) REFERENCES `users`(`id`),
  INDEX `idx_txn_order` (`order_id`),
  INDEX `idx_txn_payer` (`payer_id`),
  INDEX `idx_txn_payee` (`payee_id`),
  INDEX `idx_txn_status` (`status`),
  INDEX `idx_txn_type` (`transaction_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `escrow_deposits` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT UNSIGNED NOT NULL,
  `buyer_id` INT UNSIGNED NOT NULL,
  `amount` DECIMAL(14,2) NOT NULL,
  `deposit_reference` VARCHAR(100) DEFAULT NULL,
  `status` ENUM('pending','deposited','released_to_farmer','refunded_to_buyer','on_hold') NOT NULL DEFAULT 'pending',
  `deposited_at` DATETIME DEFAULT NULL,
  `released_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`buyer_id`) REFERENCES `users`(`id`),
  INDEX `idx_escrow_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 7. LOGISTICS - WAREHOUSES & TRANSPORT
-- ============================================================

CREATE TABLE `warehouses` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) NOT NULL,
  `warehouse_type` ENUM('dry_storage','cold_storage','silo','ripening_chamber','general') NOT NULL DEFAULT 'general',
  `operator_name` VARCHAR(200) DEFAULT NULL,
  `address` VARCHAR(500) NOT NULL,
  `district` VARCHAR(100) NOT NULL,
  `state` VARCHAR(100) NOT NULL,
  `pincode` VARCHAR(10) DEFAULT NULL,
  `latitude` DECIMAL(10,7) DEFAULT NULL,
  `longitude` DECIMAL(10,7) DEFAULT NULL,
  `total_capacity_quintals` DECIMAL(12,2) DEFAULT NULL,
  `available_capacity_quintals` DECIMAL(12,2) DEFAULT NULL,
  `daily_rate_per_quintal` DECIMAL(8,2) DEFAULT NULL,
  `min_temp_celsius` DECIMAL(5,2) DEFAULT NULL,
  `max_temp_celsius` DECIMAL(5,2) DEFAULT NULL,
  `features` TEXT DEFAULT NULL,
  `contact_phone` VARCHAR(20) DEFAULT NULL,
  `contact_email` VARCHAR(150) DEFAULT NULL,
  `rating` DECIMAL(3,2) DEFAULT 0.00,
  `is_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_warehouse_state` (`state`),
  INDEX `idx_warehouse_type` (`warehouse_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `warehouse_bookings` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `booking_code` VARCHAR(20) NOT NULL UNIQUE,
  `warehouse_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `lot_id` INT UNSIGNED DEFAULT NULL,
  `quantity_quintals` DECIMAL(12,2) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE DEFAULT NULL,
  `total_cost` DECIMAL(12,2) DEFAULT NULL,
  `status` ENUM('requested','confirmed','active','completed','cancelled') NOT NULL DEFAULT 'requested',
  `notes` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses`(`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`lot_id`) REFERENCES `farmer_lots`(`id`),
  INDEX `idx_wh_booking_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `transporters` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `provider_name` VARCHAR(200) NOT NULL,
  `vehicle_type` VARCHAR(200) NOT NULL,
  `capacity_description` VARCHAR(200) DEFAULT NULL,
  `rate_per_km` DECIMAL(8,2) DEFAULT NULL,
  `base_fare` DECIMAL(10,2) DEFAULT NULL,
  `service_area` TEXT DEFAULT NULL,
  `contact_phone` VARCHAR(20) NOT NULL,
  `contact_email` VARCHAR(150) DEFAULT NULL,
  `rating` DECIMAL(3,2) DEFAULT 0.00,
  `total_trips` INT UNSIGNED DEFAULT 0,
  `is_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `transport_bookings` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `booking_code` VARCHAR(20) NOT NULL UNIQUE,
  `transporter_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `order_id` INT UNSIGNED DEFAULT NULL,
  `lot_id` INT UNSIGNED DEFAULT NULL,
  `pickup_address` VARCHAR(500) NOT NULL,
  `delivery_address` VARCHAR(500) NOT NULL,
  `distance_km` DECIMAL(8,2) DEFAULT NULL,
  `estimated_cost` DECIMAL(12,2) DEFAULT NULL,
  `actual_cost` DECIMAL(12,2) DEFAULT NULL,
  `pickup_datetime` DATETIME DEFAULT NULL,
  `delivery_datetime` DATETIME DEFAULT NULL,
  `vehicle_number` VARCHAR(20) DEFAULT NULL,
  `driver_name` VARCHAR(100) DEFAULT NULL,
  `driver_phone` VARCHAR(20) DEFAULT NULL,
  `status` ENUM('requested','confirmed','en_route_pickup','picked_up','in_transit','delivered','cancelled') NOT NULL DEFAULT 'requested',
  `notes` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`transporter_id`) REFERENCES `transporters`(`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`),
  FOREIGN KEY (`lot_id`) REFERENCES `farmer_lots`(`id`),
  INDEX `idx_transport_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 8. FPO (Farmer Producer Organization)
-- ============================================================

CREATE TABLE `fpo_organizations` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `name_local` VARCHAR(255) DEFAULT NULL,
  `fpo_code` VARCHAR(30) NOT NULL UNIQUE,
  `registration_number` VARCHAR(50) DEFAULT NULL,
  `registration_date` DATE DEFAULT NULL,
  `state` VARCHAR(100) NOT NULL,
  `district` VARCHAR(100) NOT NULL,
  `address` VARCHAR(500) DEFAULT NULL,
  `members_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `village_count` INT UNSIGNED DEFAULT 0,
  `total_area_acres` DECIMAL(12,2) DEFAULT NULL,
  `chairman_name` VARCHAR(150) DEFAULT NULL,
  `chairman_phone` VARCHAR(20) DEFAULT NULL,
  `contact_email` VARCHAR(150) DEFAULT NULL,
  `website` VARCHAR(255) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `logo_url` VARCHAR(500) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_fpo_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `fpo_members` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `fpo_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `member_role` ENUM('chairman','director','secretary','treasurer','member') NOT NULL DEFAULT 'member',
  `land_acres` DECIMAL(10,2) DEFAULT NULL,
  `primary_crop` VARCHAR(100) DEFAULT NULL,
  `joined_date` DATE NOT NULL,
  `status` ENUM('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`fpo_id`) REFERENCES `fpo_organizations`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `uq_fpo_member` (`fpo_id`, `user_id`),
  INDEX `idx_fpo_members_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `fpo_collective_produce` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `fpo_id` INT UNSIGNED NOT NULL,
  `crop_id` INT UNSIGNED NOT NULL,
  `season` VARCHAR(50) DEFAULT NULL,
  `total_quantity` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `available_quantity` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `unit` ENUM('Quintal','Kg','Ton') NOT NULL DEFAULT 'Quintal',
  `min_price` DECIMAL(12,2) DEFAULT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`fpo_id`) REFERENCES `fpo_organizations`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`crop_id`) REFERENCES `crops`(`id`),
  INDEX `idx_fpo_produce_fpo` (`fpo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `fpo_tenders` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `tender_code` VARCHAR(20) NOT NULL UNIQUE,
  `buyer_id` INT UNSIGNED NOT NULL,
  `crop_id` INT UNSIGNED NOT NULL,
  `quantity_needed` DECIMAL(12,2) NOT NULL,
  `unit` ENUM('Quintal','Kg','Ton') NOT NULL DEFAULT 'Quintal',
  `target_price` DECIMAL(12,2) DEFAULT NULL,
  `deadline` DATE DEFAULT NULL,
  `delivery_location` VARCHAR(500) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `status` ENUM('open','bidding','awarded','closed','cancelled') NOT NULL DEFAULT 'open',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`buyer_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`crop_id`) REFERENCES `crops`(`id`),
  INDEX `idx_tender_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `fpo_bids` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `tender_id` INT UNSIGNED NOT NULL,
  `fpo_id` INT UNSIGNED NOT NULL,
  `bid_price` DECIMAL(12,2) NOT NULL,
  `quantity_offered` DECIMAL(12,2) NOT NULL,
  `delivery_timeline_days` INT UNSIGNED DEFAULT NULL,
  `message` TEXT DEFAULT NULL,
  `status` ENUM('submitted','under_review','accepted','rejected') NOT NULL DEFAULT 'submitted',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`tender_id`) REFERENCES `fpo_tenders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`fpo_id`) REFERENCES `fpo_organizations`(`id`),
  INDEX `idx_bids_tender` (`tender_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 9. GRIEVANCES & DISPUTES
-- ============================================================

CREATE TABLE `grievances` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `ticket_code` VARCHAR(20) NOT NULL UNIQUE,
  `filed_by` INT UNSIGNED NOT NULL,
  `against_user_id` INT UNSIGNED DEFAULT NULL,
  `order_id` INT UNSIGNED DEFAULT NULL,
  `category` ENUM('payment_delay','quality_rejection','pickup_noshow','price_dispute','fraud','other') NOT NULL,
  `subject` VARCHAR(300) NOT NULL,
  `description` TEXT NOT NULL,
  `evidence_urls` TEXT DEFAULT NULL COMMENT 'JSON array of file URLs',
  `amount_disputed` DECIMAL(14,2) DEFAULT NULL,
  `status` ENUM('submitted','under_review','investigation','resolved_farmer','resolved_buyer','escalated','closed') NOT NULL DEFAULT 'submitted',
  `resolution_notes` TEXT DEFAULT NULL,
  `assigned_to` INT UNSIGNED DEFAULT NULL,
  `resolved_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`filed_by`) REFERENCES `users`(`id`),
  FOREIGN KEY (`against_user_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`),
  INDEX `idx_grievance_user` (`filed_by`),
  INDEX `idx_grievance_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `grievance_updates` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `grievance_id` INT UNSIGNED NOT NULL,
  `update_by` INT UNSIGNED DEFAULT NULL,
  `update_text` TEXT NOT NULL,
  `attachment_url` VARCHAR(500) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`grievance_id`) REFERENCES `grievances`(`id`) ON DELETE CASCADE,
  INDEX `idx_grievance_upd` (`grievance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 10. NOTIFICATIONS
-- ============================================================

CREATE TABLE `notifications` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `title` VARCHAR(300) NOT NULL,
  `message` TEXT NOT NULL,
  `icon` VARCHAR(10) DEFAULT '🔔',
  `link_section` VARCHAR(50) DEFAULT NULL COMMENT 'Section to navigate to on click',
  `link_id` INT UNSIGNED DEFAULT NULL COMMENT 'Related entity ID',
  `notification_type` ENUM('offer_received','offer_accepted','offer_rejected','counter_offer','order_update','payment','price_alert','system','grievance','fpo') NOT NULL DEFAULT 'system',
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_notif_user` (`user_id`),
  INDEX `idx_notif_read` (`is_read`),
  INDEX `idx_notif_type` (`notification_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 11. TRANSLATIONS (DB-Backed i18n)
-- ============================================================

CREATE TABLE `translation_keys` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `key_name` VARCHAR(100) NOT NULL UNIQUE,
  `context` VARCHAR(100) DEFAULT NULL COMMENT 'nav, dashboard, wizard, etc',
  `description` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `translations` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `key_id` INT UNSIGNED NOT NULL,
  `language_code` VARCHAR(10) NOT NULL,
  `translated_text` TEXT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`key_id`) REFERENCES `translation_keys`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `uq_key_lang` (`key_id`, `language_code`),
  INDEX `idx_translations_lang` (`language_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `supported_languages` (
  `code` VARCHAR(10) PRIMARY KEY,
  `name_english` VARCHAR(50) NOT NULL,
  `name_native` VARCHAR(100) NOT NULL,
  `flag_emoji` VARCHAR(10) DEFAULT '🇮🇳',
  `direction` ENUM('ltr','rtl') NOT NULL DEFAULT 'ltr',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT UNSIGNED DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 12. APP SETTINGS
-- ============================================================

CREATE TABLE `app_settings` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `setting_key` VARCHAR(100) NOT NULL UNIQUE,
  `setting_value` TEXT NOT NULL,
  `setting_type` ENUM('string','number','boolean','json') NOT NULL DEFAULT 'string',
  `description` VARCHAR(255) DEFAULT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 13. AUDIT LOG
-- ============================================================

CREATE TABLE `audit_log` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `entity_type` VARCHAR(50) NOT NULL,
  `entity_id` INT UNSIGNED DEFAULT NULL,
  `old_values` JSON DEFAULT NULL,
  `new_values` JSON DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_audit_user` (`user_id`),
  INDEX `idx_audit_entity` (`entity_type`, `entity_id`),
  INDEX `idx_audit_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- INSERT SUPPORTED LANGUAGES
-- ============================================================

INSERT INTO `supported_languages` (`code`, `name_english`, `name_native`, `flag_emoji`, `direction`, `is_active`, `sort_order`) VALUES
('en', 'English', 'English', '🇮🇳', 'ltr', 1, 1),
('hi', 'Hindi', 'हिंदी', '🇮🇳', 'ltr', 1, 2),
('bn', 'Bengali', 'বাংলা', '🇮🇳', 'ltr', 1, 3),
('mr', 'Marathi', 'मराठी', '🇮🇳', 'ltr', 1, 4),
('te', 'Telugu', 'తెలుగు', '🇮🇳', 'ltr', 1, 5),
('ta', 'Tamil', 'தமிழ்', '🇮🇳', 'ltr', 1, 6),
('gu', 'Gujarati', 'ગુજરાતી', '🇮🇳', 'ltr', 1, 7),
('ur', 'Urdu', 'اردو', '🇮🇳', 'rtl', 1, 8),
('kn', 'Kannada', 'ಕನ್ನಡ', '🇮🇳', 'ltr', 1, 9),
('or', 'Odia', 'ଓଡ଼ିଆ', '🇮🇳', 'ltr', 1, 10),
('ml', 'Malayalam', 'മലയാളം', '🇮🇳', 'ltr', 1, 11),
('pa', 'Punjabi', 'ਪੰਜਾਬੀ', '🇮🇳', 'ltr', 1, 12),
('as', 'Assamese', 'অসমীয়া', '🇮🇳', 'ltr', 1, 13),
('mai', 'Maithili', 'मैथिली', '🇮🇳', 'ltr', 1, 14),
('sa', 'Sanskrit', 'संस्कृतम्', '🇮🇳', 'ltr', 1, 15),
('ne', 'Nepali', 'नेपाली', '🇮🇳', 'ltr', 1, 16),
('kok', 'Konkani', 'कोंकणी', '🇮🇳', 'ltr', 1, 17),
('sd', 'Sindhi', 'سنڌي', '🇮🇳', 'rtl', 1, 18),
('doi', 'Dogri', 'डोगरी', '🇮🇳', 'ltr', 1, 19),
('mni', 'Manipuri', 'ꯃꯩꯇꯩꯂꯣꯟ', '🇮🇳', 'ltr', 1, 20),
('brx', 'Bodo', 'बर''', '🇮🇳', 'ltr', 1, 21),
('sat', 'Santali', 'ᱥᱟᱱᱛᱟᱲᱤ', '🇮🇳', 'ltr', 1, 22),
('ks', 'Kashmiri', 'کأشُر', '🇮🇳', 'rtl', 1, 23);

-- ============================================================
-- INSERT DEFAULT APP SETTINGS
-- ============================================================

INSERT INTO `app_settings` (`setting_key`, `setting_value`, `setting_type`, `description`) VALUES
('platform_name', 'KisanSetu', 'string', 'Platform display name'),
('platform_fee_percent', '0.50', 'number', 'Platform fee percentage on transactions'),
('default_language', 'en', 'string', 'Default language code'),
('currency_symbol', '₹', 'string', 'Currency symbol'),
('default_price_unit', 'Quintal', 'string', 'Default price unit'),
('max_upload_size_mb', '10', 'number', 'Maximum file upload size in MB'),
('escrow_enabled', 'true', 'boolean', 'Whether escrow is enabled'),
('auto_expire_lots_days', '30', 'number', 'Auto-expire lots after N days'),
('auto_expire_offers_days', '7', 'number', 'Auto-expire offers after N days'),
('min_lot_quantity', '10', 'number', 'Minimum lot quantity in quintals'),
('grievance_sla_hours', '48', 'number', 'Grievance resolution SLA in hours');

-- ============================================================
-- INSERT CROP CATEGORIES
-- ============================================================

INSERT INTO `crop_categories` (`id`, `name`, `name_hi`, `icon`, `sort_order`) VALUES
(1, 'Cereals', 'अनाज', '🌾', 1),
(2, 'Vegetables', 'सब्जियां', '🥬', 2),
(3, 'Oilseeds', 'तिलहन', '🌻', 3),
(4, 'Fiber', 'रेशा', '☁️', 4),
(5, 'Pulses', 'दालें', '🫘', 5),
(6, 'Fruits', 'फल', '🍎', 6),
(7, 'Spices', 'मसाले', '🌶️', 7),
(8, 'Sugarcane & Others', 'गन्ना व अन्य', '🌿', 8);

COMMIT;
