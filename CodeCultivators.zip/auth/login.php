<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

// Redirect if already logged in
if (isset($_SESSION['user'])) {
    header('Location: ' . APP_BASE_URL . '/farmer_kisan_setu.PHP');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = sanitize($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($phone) || empty($password)) {
        $error = 'Please enter phone number and password.';
    } else {
        try {
            $db = getDB();
            $stmt = $db->prepare("SELECT id, phone, password_hash, role, full_name, display_name, avatar_url, preferred_language, is_verified, is_active FROM users WHERE phone = ? LIMIT 1");
            $stmt->execute([$phone]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                if (!$user['is_active']) {
                    $error = 'Your account has been deactivated. Please contact support.';
                } else {
                    // Set session
                    $_SESSION['user'] = [
                        'id' => $user['id'],
                        'phone' => $user['phone'],
                        'role' => $user['role'],
                        'full_name' => $user['full_name'],
                        'display_name' => $user['display_name'] ?: $user['full_name'],
                        'avatar_url' => $user['avatar_url'],
                        'preferred_language' => $user['preferred_language'],
                        'is_verified' => $user['is_verified']
                    ];
                    $_SESSION['last_activity'] = time();

                    // Update last login
                    $db->prepare("UPDATE users SET last_login_at = NOW() WHERE id = ?")->execute([$user['id']]);

                    // Redirect based on role
                    if (in_array($user['role'], ['buyer', 'merchant'])) {
                        header('Location: ' . APP_BASE_URL . '/merchant/dashboard.php');
                    } else {
                        header('Location: ' . APP_BASE_URL . '/farmer_kisan_setu.PHP');
                    }
                    exit;
                }
            } else {
                $error = 'Invalid phone number or password.';
            }
        } catch (PDOException $e) {
            $error = 'Login failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - KisanSetu</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        .auth-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #064e3b 0%, #059669 50%, #0284c7 100%);
            padding: 20px;
        }
        .auth-card {
            background: white;
            border-radius: var(--radius-lg);
            padding: 40px 32px;
            max-width: 440px;
            width: 100%;
            box-shadow: 0 25px 50px rgba(0,0,0,0.25);
        }
        .auth-brand {
            text-align: center;
            margin-bottom: 32px;
        }
        .auth-brand-icon {
            width: 72px; height: 72px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-md);
            display: inline-flex; align-items: center; justify-content: center;
            font-size: 36px; margin-bottom: 12px;
            box-shadow: 0 8px 20px rgba(5,150,105,0.3);
        }
        .auth-brand h1 { font-size: 28px; font-weight: 800; color: var(--primary-dark); }
        .auth-brand p { font-size: 14px; color: var(--text-muted); margin-top: 4px; }
        .auth-error {
            background: #fef2f2; border: 1px solid #fecaca; color: #dc2626;
            padding: 12px 16px; border-radius: var(--radius-sm);
            font-size: 14px; font-weight: 600; margin-bottom: 20px;
        }
        .auth-success {
            background: #f0fdf4; border: 1px solid #bbf7d0; color: #16a34a;
            padding: 12px 16px; border-radius: var(--radius-sm);
            font-size: 14px; font-weight: 600; margin-bottom: 20px;
        }
        .auth-footer {
            text-align: center; margin-top: 24px;
            padding-top: 20px; border-top: 1px solid var(--border);
        }
        .auth-footer a { color: var(--primary); font-weight: 700; text-decoration: none; }
        .auth-footer a:hover { text-decoration: underline; }
        .role-picker { display: flex; gap: 10px; margin-bottom: 20px; }
        .role-pick-btn {
            flex: 1; padding: 14px; border: 2px solid var(--border);
            border-radius: var(--radius-sm); background: white;
            cursor: pointer; text-align: center; font-weight: 700;
            font-size: 15px; transition: all 0.2s;
        }
        .role-pick-btn.active { border-color: var(--primary); background: var(--primary-light); color: var(--primary-dark); }
        .role-pick-btn:hover { border-color: var(--primary); }
    </style>
</head>
<body>
    <div class="auth-page">
        <div class="auth-card">
            <div class="auth-brand">
                <div class="auth-brand-icon">🌾</div>
                <h1>KisanSetu</h1>
                <p>Farmer-Buyer Market Linkage Platform</p>
            </div>

            <?php if ($error): ?>
                <div class="auth-error">⚠️ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if (isset($_GET['registered'])): ?>
                <div class="auth-success">✅ Registration successful! Please log in.</div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label class="form-label">📱 Phone Number</label>
                    <input type="tel" name="phone" class="form-input" placeholder="+91 98765 43210" required
                           value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">🔒 Password</label>
                    <input type="password" name="password" class="form-input" placeholder="Enter your password" required>
                </div>

                <button type="submit" class="btn btn-primary btn-full" style="font-size:16px; padding:14px;">
                    🔑 Sign In
                </button>
            </form>

            <div class="auth-footer">
                <p style="color:var(--text-muted); font-size:14px;">Don't have an account?</p>
                <a href="register.php" style="font-size:16px;">📝 Create Account (Farmer / Buyer)</a>
            </div>
        </div>
    </div>
</body>
</html>
