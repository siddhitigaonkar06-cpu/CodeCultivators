<?php
require_once __DIR__ . '/../config/app.php';
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}
$_SESSION = [];
session_destroy();
header('Location: ' . APP_BASE_URL . '/auth/login.php');
exit;
