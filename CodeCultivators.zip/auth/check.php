<?php
// Auth Guard - Include in all authenticated pages
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

if (!isset($_SESSION['user'])) {
    if (isAjaxRequest()) {
        jsonResponse(['error' => 'Authentication required'], 401);
    } else {
        header('Location: ' . APP_BASE_URL . '/auth/login.php');
        exit;
    }
}

// Refresh last activity
$_SESSION['last_activity'] = time();
