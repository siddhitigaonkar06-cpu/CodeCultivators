<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

if (isset($_SESSION['user'])) {
    header('Location: ' . APP_BASE_URL . '/farmer_kisan_setu.PHP');
    exit;
}

$error = '';
$selectedRole = 'farmer';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $role = in_array($_POST['role'] ?? '', ['farmer', 'buyer', 'merchant']) ? $_POST['role'] : 'farmer';
    $selectedRole = $role;

    $village = sanitize($_POST['village'] ?? '');
    $district = sanitize($_POST['district'] ?? '');
    $state = sanitize($_POST['state'] ?? '');
    $pincode = sanitize($_POST['pincode'] ?? '');
    $bank_name = sanitize($_POST['bank_name'] ?? '');
    $account_number = sanitize($_POST['account_number'] ?? '');
    $ifsc_code = sanitize($_POST['ifsc_code'] ?? '');
    $upi_id = sanitize($_POST['upi_id'] ?? '');
    $firm_name = sanitize($_POST['firm_name'] ?? '');
    $land_acres = floatval($_POST['land_acres'] ?? 0);

    if (empty($full_name) || empty($phone) || empty($password)) {
        $error = 'Name, phone, and password are required.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (empty($district) || empty($state)) {
        $error = 'District and State are required.';
    } else {
        try {
            $db = getDB();

            // Check if phone exists
            $check = $db->prepare("SELECT id FROM users WHERE phone = ?");
            $check->execute([$phone]);
            if ($check->fetch()) {
                $error = 'This phone number is already registered.';
            } else {
                $db->beginTransaction();

                // Create user
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $db->prepare("INSERT INTO users (phone, password_hash, role, full_name, display_name) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$phone, $hash, $role, $full_name, $full_name]);
                $userId = $db->lastInsertId();

                // Create profile
                $stmt = $db->prepare("INSERT INTO user_profiles (user_id, firm_name, total_land_acres) VALUES (?, ?, ?)");
                $stmt->execute([$userId, $firm_name ?: null, $land_acres > 0 ? $land_acres : null]);

                // Create address
                if (!empty($district)) {
                    $stmt = $db->prepare("INSERT INTO user_addresses (user_id, address_line1, village, district, state, pincode) VALUES (?, ?, ?, ?, ?, ?)");
                    $addrLine = $village ? "Village $village, Dist. $district, $state" : "Dist. $district, $state";
                    $stmt->execute([$userId, $addrLine, $village, $district, $state, $pincode]);
                }

                // Create bank details
                if (!empty($bank_name) && !empty($account_number)) {
                    $stmt = $db->prepare("INSERT INTO user_bank_details (user_id, account_holder_name, bank_name, account_number, ifsc_code, upi_id) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$userId, $full_name, $bank_name, $account_number, $ifsc_code, $upi_id ?: null]);
                }

                $db->commit();
                header('Location: login.php?registered=1');
                exit;
            }
        } catch (PDOException $e) {
            if (isset($db) && $db->inTransaction()) $db->rollBack();
            $error = 'Registration failed. Please try again. ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - KisanSetu</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        .auth-page {
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
            background: linear-gradient(135deg, #064e3b 0%, #059669 50%, #0284c7 100%);
            padding: 20px;
        }
        .auth-card {
            background: white; border-radius: var(--radius-lg);
            padding: 36px 28px; max-width: 540px; width: 100%;
            box-shadow: 0 25px 50px rgba(0,0,0,0.25);
            max-height: 90vh; overflow-y: auto;
        }
        .auth-brand { text-align: center; margin-bottom: 24px; }
        .auth-brand-icon {
            width: 64px; height: 64px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-md);
            display: inline-flex; align-items: center; justify-content: center;
            font-size: 32px; margin-bottom: 8px;
        }
        .auth-brand h1 { font-size: 24px; font-weight: 800; color: var(--primary-dark); }
        .auth-error {
            background: #fef2f2; border: 1px solid #fecaca; color: #dc2626;
            padding: 12px 16px; border-radius: var(--radius-sm);
            font-size: 14px; font-weight: 600; margin-bottom: 16px;
        }
        .auth-footer {
            text-align: center; margin-top: 20px;
            padding-top: 16px; border-top: 1px solid var(--border);
        }
        .auth-footer a { color: var(--primary); font-weight: 700; }
        .role-picker { display: flex; gap: 10px; margin-bottom: 20px; }
        .role-pick-btn {
            flex: 1; padding: 14px 10px; border: 2px solid var(--border);
            border-radius: var(--radius-sm); background: white;
            cursor: pointer; text-align: center; font-weight: 700;
            font-size: 14px; transition: all 0.2s;
        }
        .role-pick-btn.active { border-color: var(--primary); background: var(--primary-light); color: var(--primary-dark); }
        .role-pick-btn:hover { border-color: var(--primary); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        @media (max-width: 500px) { .form-row { grid-template-columns: 1fr; } }
        .section-divider {
            font-size: 14px; font-weight: 800; color: var(--primary-dark);
            margin: 20px 0 12px; padding-bottom: 6px;
            border-bottom: 2px solid var(--primary-light);
        }
        .buyer-fields, .farmer-fields { transition: all 0.3s; }
    </style>
</head>
<body>
    <div class="auth-page">
        <div class="auth-card">
            <div class="auth-brand">
                <div class="auth-brand-icon">🌾</div>
                <h1>Create Your Account</h1>
            </div>

            <?php if ($error): ?>
                <div class="auth-error">⚠️ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <!-- Role Picker -->
                <div class="section-divider">👤 I am a...</div>
                <div class="role-picker">
                    <label class="role-pick-btn <?= $selectedRole === 'farmer' ? 'active' : '' ?>" onclick="pickRole('farmer',this)">
                        <input type="radio" name="role" value="farmer" <?= $selectedRole === 'farmer' ? 'checked' : '' ?> style="display:none;">
                        👨‍🌾 Farmer
                    </label>
                    <label class="role-pick-btn <?= $selectedRole === 'buyer' ? 'active' : '' ?>" onclick="pickRole('buyer',this)">
                        <input type="radio" name="role" value="buyer" <?= $selectedRole === 'buyer' ? 'checked' : '' ?> style="display:none;">
                        💼 Buyer
                    </label>
                    <label class="role-pick-btn <?= $selectedRole === 'merchant' ? 'active' : '' ?>" onclick="pickRole('merchant',this)">
                        <input type="radio" name="role" value="merchant" <?= $selectedRole === 'merchant' ? 'checked' : '' ?> style="display:none;">
                        🏢 Merchant
                    </label>
                </div>

                <!-- Basic Info -->
                <div class="section-divider">📋 Basic Details</div>
                <div class="form-group">
                    <label class="form-label">Full Name *</label>
                    <input type="text" name="full_name" class="form-input" placeholder="Your full name" required
                           value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">📱 Phone Number *</label>
                        <input type="tel" name="phone" class="form-input" placeholder="+91 98765 43210" required
                               value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                    </div>
                    <div class="form-group farmer-fields">
                        <label class="form-label">🌾 Total Land (Acres)</label>
                        <input type="number" name="land_acres" class="form-input" step="0.5" placeholder="e.g. 4.5"
                               value="<?= htmlspecialchars($_POST['land_acres'] ?? '') ?>">
                    </div>
                </div>

                <div class="buyer-fields" style="display:<?= in_array($selectedRole, ['buyer','merchant']) ? 'block' : 'none' ?>">
                    <div class="form-group">
                        <label class="form-label">🏢 Firm / Company Name</label>
                        <input type="text" name="firm_name" class="form-input" placeholder="Your firm name"
                               value="<?= htmlspecialchars($_POST['firm_name'] ?? '') ?>">
                    </div>
                </div>

                <!-- Password -->
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">🔒 Password *</label>
                        <input type="password" name="password" class="form-input" placeholder="Min 6 characters" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label class="form-label">🔒 Confirm Password *</label>
                        <input type="password" name="confirm_password" class="form-input" placeholder="Repeat password" required>
                    </div>
                </div>

                <!-- Location -->
                <div class="section-divider">📍 Location</div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Village</label>
                        <input type="text" name="village" class="form-input" placeholder="Village name"
                               value="<?= htmlspecialchars($_POST['village'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">District *</label>
                        <input type="text" name="district" class="form-input" placeholder="District" required
                               value="<?= htmlspecialchars($_POST['district'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">State *</label>
                        <input type="text" name="state" class="form-input" placeholder="State" required
                               value="<?= htmlspecialchars($_POST['state'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">PIN Code</label>
                        <input type="text" name="pincode" class="form-input" placeholder="PIN code"
                               value="<?= htmlspecialchars($_POST['pincode'] ?? '') ?>">
                    </div>
                </div>

                <!-- Bank Details -->
                <div class="section-divider">🏦 Bank Details (for payouts)</div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Bank Name</label>
                        <input type="text" name="bank_name" class="form-input" placeholder="e.g. State Bank of India"
                               value="<?= htmlspecialchars($_POST['bank_name'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Account Number</label>
                        <input type="text" name="account_number" class="form-input" placeholder="Account number"
                               value="<?= htmlspecialchars($_POST['account_number'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">IFSC Code</label>
                        <input type="text" name="ifsc_code" class="form-input" placeholder="SBIN0001234"
                               value="<?= htmlspecialchars($_POST['ifsc_code'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">UPI ID</label>
                        <input type="text" name="upi_id" class="form-input" placeholder="yourname@bank"
                               value="<?= htmlspecialchars($_POST['upi_id'] ?? '') ?>">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-full" style="font-size:16px; padding:14px; margin-top:8px;">
                    🚀 Create Account
                </button>
            </form>

            <div class="auth-footer">
                <p style="color:var(--text-muted); font-size:14px;">Already have an account?
                    <a href="login.php">Sign In</a>
                </p>
            </div>
        </div>
    </div>

    <script>
        function pickRole(role, el) {
            document.querySelectorAll('.role-pick-btn').forEach(b => b.classList.remove('active'));
            el.classList.add('active');
            el.querySelector('input[type=radio]').checked = true;
            document.querySelector('.buyer-fields').style.display =
                (role === 'buyer' || role === 'merchant') ? 'block' : 'none';
            document.querySelector('.farmer-fields').style.display =
                role === 'farmer' ? 'block' : 'none';
        }
    </script>
</body>
</html>
