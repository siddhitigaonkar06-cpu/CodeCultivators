<?php
// KisanSetu Application Configuration
define('APP_NAME', 'KisanSetu');
define('APP_VERSION', '2.0.0');
define('APP_BASE_URL', '/FarmER');
define('APP_ROOT', dirname(__DIR__));

// Upload configuration
define('UPLOAD_DIR', APP_ROOT . '/uploads');
define('UPLOAD_URL', APP_BASE_URL . '/uploads');
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

// Session configuration
define('SESSION_LIFETIME', 86400 * 7); // 7 days
define('SESSION_NAME', 'KISANSETU_SID');

// Supported languages
define('SUPPORTED_LANGUAGES', [
    'en','hi','bn','mr','te','ta','gu','ur','kn','or','ml','pa',
    'as','mai','sa','ne','kok','sd','doi','mni','brx','sat','ks'
]);
define('DEFAULT_LANGUAGE', 'en');

// Platform fees
define('PLATFORM_FEE_PERCENT', 0.50);

// Ensure upload directory exists
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

// Helper: generate unique codes
function generateCode($prefix, $length = 4) {
    return $prefix . '-' . str_pad(mt_rand(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
}

// Helper: JSON response
function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Helper: get current user from session
function getCurrentUser() {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_start();
    }
    return $_SESSION['user'] ?? null;
}

// Helper: require login
function requireLogin() {
    $user = getCurrentUser();
    if (!$user) {
        if (isAjaxRequest()) {
            jsonResponse(['error' => 'Authentication required'], 401);
        } else {
            header('Location: ' . APP_BASE_URL . '/auth/login.php');
            exit;
        }
    }
    return $user;
}

// Helper: check if AJAX
function isAjaxRequest() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

// Helper: sanitize input
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
